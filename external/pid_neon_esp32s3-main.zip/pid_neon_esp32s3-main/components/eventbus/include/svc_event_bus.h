/**
 * svc_event_bus.h — шина подій (патерн Observer / Publish–Subscribe).
 *
 * Видавець (задача вводу, контролер мотора, регулятор) повідомляє про подію,
 * не знаючи, хто слухає. Наприклад, одне клацання енкодера отримують ОДРАЗУ
 * два незалежні модулі — мотор і PID-регулятор, — а задача вводу про жоден
 * із них не знає. Додати новий "слухач" = один виклик Subscribe,
 * код видавця не змінюється.
 *
 * Обмеження (спрощення для МК):
 *  - підписка лише під час ініціалізації (до старту планувальника), тому
 *    масив підписників незмінний під час роботи → блокування не потрібні;
 *  - колбек виконується в контексті задачі-видавця → має бути КОРОТКИМ
 *    і не блокуватись (без vTaskDelay, без очікування на черзі).
 */
#ifndef SVC_EVENT_BUS_H
#define SVC_EVENT_BUS_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    TOPIC_ENCODER_STEP = 0,  /* value = +N (за годинниковою) / −N (проти) клацань   */
    TOPIC_BUTTON,            /* value = 1: натиснули кнопку енкодера                */
    TOPIC_MOTOR_STATE,       /* value = MotorState_t                                */
    TOPIC_REG_SETTLED,       /* value = 1: PID вийшов на уставку, 0: ще перехідний  */
    TOPIC_COUNT
} BusTopic_t;

typedef void (*BusCallback_t)(void *ctx, BusTopic_t topic, int32_t value);

#define EVENT_BUS_MAX_SUBSCRIBERS  8

bool EventBus_Subscribe(BusTopic_t topic, BusCallback_t cb, void *ctx);
void EventBus_Publish  (BusTopic_t topic, int32_t value);

#endif /* SVC_EVENT_BUS_H */
