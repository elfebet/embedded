/**
 * svc_event_bus.c — статична таблиця підписників, без динамічної пам'яті.
 */
#include "svc_event_bus.h"
#include <stddef.h>

typedef struct {
    BusTopic_t    topic;
    BusCallback_t cb;
    void         *ctx;
} Subscriber_t;

static Subscriber_t subs[EVENT_BUS_MAX_SUBSCRIBERS];
static uint8_t      n_subs;

bool EventBus_Subscribe(BusTopic_t topic, BusCallback_t cb, void *ctx)
{
    if (cb == NULL || topic >= TOPIC_COUNT || n_subs >= EVENT_BUS_MAX_SUBSCRIBERS)
        return false;
    subs[n_subs++] = (Subscriber_t){ .topic = topic, .cb = cb, .ctx = ctx };
    return true;
}

void EventBus_Publish(BusTopic_t topic, int32_t value)
{
    for (uint8_t i = 0; i < n_subs; i++) {
        if (subs[i].topic == topic)
            subs[i].cb(subs[i].ctx, topic, value);
    }
}
