/**
 * alg_pid.c — програмний PID-регулятор (чиста математика, без HAL і RTOS)
 *
 * u = Kp*e + Ki*∫e dt − Kd * d(y_f)/dt
 * D — по вимірюванню y (а не по похибці), пропущена через ФНЧ зі сталою tau.
 */
#include "alg_pid.h"

static inline float clampf(float x, float lo, float hi)
{
    return (x < lo) ? lo : (x > hi) ? hi : x;
}

void PID_Init(PID_Controller_t *pid, float kp, float ki, float kd,
              float ts, float tau, float out_min, float out_max)
{
    pid->ts      = ts;
    pid->tau     = tau;
    pid->out_min = out_min;
    pid->out_max = out_max;
    PID_SetGains(pid, kp, ki, kd);
    PID_Reset(pid);
}

void PID_SetGains(PID_Controller_t *pid, float kp, float ki, float kd)
{
    /* integ вже містить Ki, тому зміна Ki "на льоту" не дає стрибка виходу */
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
}

void PID_Reset(PID_Controller_t *pid)
{
    pid->integ = 0.0f;
    pid->diff  = 0.0f;
    pid->prev_meas = 0.0f;
    pid->first = true;
    pid->p_term = pid->i_term = pid->d_term = 0.0f;
}

float PID_Update(PID_Controller_t *pid, float setpoint, float measurement)
{
    if (pid->first) {                 /* немає "удару" D на першому кроці */
        pid->prev_meas = measurement;
        pid->first = false;
    }

    const float err = setpoint - measurement;

    /* P */
    const float p = pid->kp * err;

    /* D по вимірюванню, ФНЧ 1-го порядку (Тастін):
       d[k] = (2τ−T)/(2τ+T)·d[k−1] − 2Kd/(2τ+T)·(y[k]−y[k−1]) */
    const float a = (2.0f * pid->tau - pid->ts) / (2.0f * pid->tau + pid->ts);
    const float b = (2.0f * pid->kd)           / (2.0f * pid->tau + pid->ts);
    pid->diff = a * pid->diff - b * (measurement - pid->prev_meas);
    pid->prev_meas = measurement;

    /* I (метод трапецій не потрібен — прямокутники досить при малому T) */
    const float di = pid->ki * err * pid->ts;
    const float u_unsat = p + pid->integ + di + pid->diff;

    /* Anti-windup (умовне інтегрування): не інтегруємо, якщо вихід
       у насиченні і похибка штовхає його ще далі в насичення */
    const bool sat_hi = (u_unsat > pid->out_max) && (err > 0.0f);
    const bool sat_lo = (u_unsat < pid->out_min) && (err < 0.0f);
    if (!sat_hi && !sat_lo) {
        pid->integ += di;
    }
    pid->integ = clampf(pid->integ, pid->out_min, pid->out_max);

    const float u = clampf(p + pid->integ + pid->diff, pid->out_min, pid->out_max);

    pid->p_term = p;
    pid->i_term = pid->integ;
    pid->d_term = pid->diff;
    return u;
}
