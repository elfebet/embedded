/**
 * drv_motor.h — АБСТРАКТНИЙ інтерфейс мотора ("що вміє мотор", без "як").
 *
 * Патерн: Strategy / Interface (таблиця вказівників на функції — "віртуальні
 * методи" на C). Логіка керування (app_motor_fsm) працює з Motor_t і не знає,
 * що всередині два реле. Завтра замініть реле на драйвер MX1616 чи L293D —
 * напишіть drv_motor_hbridge.c з тими ж двома функціями, і в логіці не зміниться
 * жоден рядок (принцип Open/Closed, Dependency Inversion).
 */
#ifndef DRV_MOTOR_H
#define DRV_MOTOR_H

typedef enum {
    MOTOR_DIR_CW = 0,     /* за годинниковою стрілкою */
    MOTOR_DIR_CCW         /* проти годинникової        */
} MotorDir_t;

typedef struct {
    void (*run) (void *self, MotorDir_t dir);
    void (*stop)(void *self);
} MotorOps_t;

typedef struct {
    const MotorOps_t *ops;   /* "vtable"                         */
    void             *self;  /* конкретний об'єкт реалізації     */
} Motor_t;

static inline void Motor_Run (const Motor_t *m, MotorDir_t dir) { m->ops->run(m->self, dir); }
static inline void Motor_Stop(const Motor_t *m)                 { m->ops->stop(m->self); }

#endif /* DRV_MOTOR_H */
