/**
 * app_motor_fsm.h — скінченний автомат станів мотора (патерн State).
 *
 * ЧИСТА ЛОГІКА: не залежить ні від HAL, ні від FreeRTOS. Час приходить
 * параметром, мотор — через інтерфейс Motor_t. Тому модуль тестується
 * на звичайному ПК (tests/test_motor_fsm.c).
 *
 *            STEP_CW                      STEP_CCW
 *   ┌──────► RUN_CW ───────────┐   ┌──── RUN_CCW ◄──────┐
 *   │          │ STOP / тайм-аут│   │ STOP / тайм-аут│    │
 *   │          ▼   STEP_CCW     ▼   ▼   STEP_CW     ▼    │
 * IDLE ◄──────────────────  SWITCHING  ──────────────────┘
 *   ▲        STOP             (пауза CFG_DEADTIME_MS,
 *   │                          потім вмикає останній обраний напрямок)
 */
#ifndef APP_MOTOR_FSM_H
#define APP_MOTOR_FSM_H

#include "drv_motor.h"
#include <stdbool.h>
#include <stdint.h>

typedef enum {
    MS_IDLE = 0,       /* мотор стоїть                                   */
    MS_RUN_CW,         /* крутиться за годинниковою                      */
    MS_RUN_CCW,        /* крутиться проти                                */
    MS_SWITCHING,      /* мотор зупинено, чекаємо паузу перед реверсом   */
    MS_COUNT
} MotorState_t;

typedef enum {
    MEV_STEP_CW = 0,   /* енкодер клацнув за годинниковою */
    MEV_STEP_CCW,      /* енкодер клацнув проти           */
    MEV_STOP,          /* кнопка: аварійна зупинка        */
    MEV_TICK           /* періодичний такт (для таймерів) */
} MotorEvent_t;

typedef void (*MotorStateCb_t)(void *ctx, MotorState_t new_state);

typedef struct {
    uint32_t deadtime_ms;      /* пауза між напрямками                          */
    uint32_t idle_timeout_ms;  /* зупинка, якщо енкодер не крутять; 0 = вимкнено */
} MotorFsmConfig_t;

typedef struct {
    MotorState_t     state;
    MotorDir_t       target;        /* куди поїдемо після паузи             */
    uint32_t         t_last_step;   /* коли було останнє клацання           */
    uint32_t         t_stopped;     /* коли мотор востаннє зупинили         */
    MotorFsmConfig_t cfg;
    Motor_t          motor;
    MotorStateCb_t   on_state;      /* сповіщення про зміну стану (Observer) */
    void            *cb_ctx;
} MotorFsm_t;

void         MotorFsm_Init(MotorFsm_t *f, const MotorFsmConfig_t *cfg, Motor_t motor,
                           MotorStateCb_t on_state, void *cb_ctx, uint32_t now_ms);
void         MotorFsm_Dispatch(MotorFsm_t *f, MotorEvent_t ev, uint32_t now_ms);
MotorState_t MotorFsm_State(const MotorFsm_t *f);
const char  *MotorFsm_StateName(MotorState_t s);

#endif /* APP_MOTOR_FSM_H */
