/**
 * alg_pid.h — алгоритм PID-регулятора (шар "алгоритми": чиста математика).
 *
 * Не залежить ні від HAL, ні від FreeRTOS → тестується на ПК (tests/test_pid.c)
 * разом із моделлю RC-кола.
 *
 * Особливості реалізації (питання на захисті):
 *  - D-складова рахується по ВИМІРЮВАННЮ, а не по похибці → немає "удару"
 *    у виході, коли енкодером різко змінюють уставку;
 *  - D-складова пропущена через ФНЧ 1-го порядку → не підсилює шум АЦП;
 *  - anti-windup: умовне інтегрування + обмеження інтегратора → після
 *    насичення ШІМ вихід не "перелітає" уставку;
 *  - інтегратор зберігає вже помножене Ki·∫e → зміна Ki на льоту без стрибка.
 */
#ifndef ALG_PID_H
#define ALG_PID_H

#include <stdbool.h>

typedef struct {
    /* параметри */
    float kp, ki, kd;
    float ts;              /* період дискретизації, с                 */
    float tau;             /* стала часу ФНЧ D-складової, с (>= 2*ts) */
    float out_min, out_max;

    /* стан */
    float integ;           /* I-складова (вже з Ki)                   */
    float diff;            /* відфільтрована D-складова               */
    float prev_meas;
    bool  first;

    /* останні складові — для діагностики в дебагері */
    float p_term, i_term, d_term;
} PID_Controller_t;

void  PID_Init(PID_Controller_t *pid, float kp, float ki, float kd,
               float ts, float tau, float out_min, float out_max);
void  PID_SetGains(PID_Controller_t *pid, float kp, float ki, float kd);
void  PID_Reset(PID_Controller_t *pid);
float PID_Update(PID_Controller_t *pid, float setpoint, float measurement);

#endif /* ALG_PID_H */
