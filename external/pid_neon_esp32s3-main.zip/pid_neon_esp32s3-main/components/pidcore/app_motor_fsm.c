/**
 * app_motor_fsm.c — реалізація автомата станів.
 *
 * Патерн State у C: кожному стану відповідає функція-обробник, а таблиця
 * STATE_HANDLERS[] вибирає потрібну за поточним станом. Додати новий стан =
 * дописати enum + одну функцію + рядок у таблиці, без гігантського switch.
 *
 * Весь час — у мс, беззнаковий: (now - t) коректне і після переповнення uint32.
 */
#include "app_motor_fsm.h"
#include <stddef.h>

typedef void (*StateHandler_t)(MotorFsm_t *f, MotorEvent_t ev, uint32_t now);

/* ----------------------------- допоміжні дії ----------------------------- */
static void enter(MotorFsm_t *f, MotorState_t s)
{
    if (f->state == s) return;
    f->state = s;
    if (f->on_state) f->on_state(f->cb_ctx, s);
}

static void motor_stop(MotorFsm_t *f, uint32_t now)
{
    Motor_Stop(&f->motor);
    f->t_stopped = now;
}

/* t_last_step тут НЕ оновлюємо: тайм-аут рахується від останнього клацання
   енкодера, а не від моменту, коли після паузи нарешті ввімкнули мотор. */
static void motor_start(MotorFsm_t *f, MotorDir_t dir)
{
    Motor_Run(&f->motor, dir);
    enter(f, dir == MOTOR_DIR_CW ? MS_RUN_CW : MS_RUN_CCW);
}

static bool is_step(MotorEvent_t ev, MotorDir_t *dir)
{
    if (ev == MEV_STEP_CW)  { *dir = MOTOR_DIR_CW;  return true; }
    if (ev == MEV_STEP_CCW) { *dir = MOTOR_DIR_CCW; return true; }
    return false;
}

/* Мотор міг зупинитися щойно (на вибігу ще крутиться) — тоді реверс лише після паузи */
static void request_direction(MotorFsm_t *f, MotorDir_t dir, uint32_t now)
{
    f->t_last_step = now;
    if ((uint32_t)(now - f->t_stopped) >= f->cfg.deadtime_ms) {
        motor_start(f, dir);
    } else {
        f->target = dir;
        enter(f, MS_SWITCHING);
    }
}

/* ------------------------------- стани ------------------------------- */
static void st_idle(MotorFsm_t *f, MotorEvent_t ev, uint32_t now)
{
    MotorDir_t dir;
    if (is_step(ev, &dir)) request_direction(f, dir, now);
    /* STOP і TICK у стані спокою нічого не роблять */
}

static void st_running(MotorFsm_t *f, MotorEvent_t ev, uint32_t now)
{
    MotorDir_t cur = (f->state == MS_RUN_CW) ? MOTOR_DIR_CW : MOTOR_DIR_CCW;
    MotorDir_t dir;

    if (is_step(ev, &dir)) {
        if (dir == cur) {                  /* крутимо далі в той самий бік */
            f->t_last_step = now;
        } else {                           /* реверс: стоп → пауза → інший бік */
            motor_stop(f, now);
            f->t_last_step = now;
            f->target = dir;
            enter(f, MS_SWITCHING);
        }
        return;
    }

    if (ev == MEV_STOP) {
        motor_stop(f, now);
        enter(f, MS_IDLE);
        return;
    }

    if (ev == MEV_TICK && f->cfg.idle_timeout_ms != 0 &&
        (uint32_t)(now - f->t_last_step) >= f->cfg.idle_timeout_ms) {
        motor_stop(f, now);                /* енкодер відпустили */
        enter(f, MS_IDLE);
    }
}

static void st_switching(MotorFsm_t *f, MotorEvent_t ev, uint32_t now)
{
    MotorDir_t dir;

    if (is_step(ev, &dir)) {               /* передумали під час паузи — беремо останній */
        f->target = dir;
        f->t_last_step = now;
        return;
    }

    if (ev == MEV_STOP) {                  /* мотор уже вимкнений */
        enter(f, MS_IDLE);
        return;
    }

    if (ev == MEV_TICK && (uint32_t)(now - f->t_stopped) >= f->cfg.deadtime_ms) {
        motor_start(f, f->target);
    }
}

static const StateHandler_t STATE_HANDLERS[MS_COUNT] = {
    [MS_IDLE]      = st_idle,
    [MS_RUN_CW]    = st_running,
    [MS_RUN_CCW]   = st_running,
    [MS_SWITCHING] = st_switching,
};

/* ------------------------------ публічне API ------------------------------ */
void MotorFsm_Init(MotorFsm_t *f, const MotorFsmConfig_t *cfg, Motor_t motor,
                   MotorStateCb_t on_state, void *cb_ctx, uint32_t now_ms)
{
    f->cfg      = *cfg;
    f->motor    = motor;
    f->on_state = on_state;
    f->cb_ctx   = cb_ctx;
    f->state    = MS_IDLE;
    f->target   = MOTOR_DIR_CW;
    f->t_last_step = now_ms;
    f->t_stopped   = now_ms - cfg->deadtime_ms;   /* перший старт — без паузи */
    Motor_Stop(&f->motor);
}

void MotorFsm_Dispatch(MotorFsm_t *f, MotorEvent_t ev, uint32_t now_ms)
{
    if (f->state < MS_COUNT && STATE_HANDLERS[f->state] != NULL)
        STATE_HANDLERS[f->state](f, ev, now_ms);
}

MotorState_t MotorFsm_State(const MotorFsm_t *f)
{
    return f->state;
}

const char *MotorFsm_StateName(MotorState_t s)
{
    static const char *const NAMES[MS_COUNT] = { "IDLE", "RUN_CW", "RUN_CCW", "SWITCHING" };
    return (s < MS_COUNT) ? NAMES[s] : "?";
}
