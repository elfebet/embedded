/**
 * net_web.h — вебсервер: сторінка, WebSocket і REST API.
 *
 *   GET  /            → вебсторінка (вшита у прошивку як бінарний ресурс)
 *   GET  /ws          → WebSocket: сервер штовхає телеметрію (push),
 *                       браузер надсилає команди (повзунок, STOP, PID)
 *   GET  /api/status  → те саме JSON, що й по WebSocket (REST, pull)
 *   POST /api/cmd     → команда в тілі запиту (REST): {"cmd":"enc","steps":3}
 *
 * Чому WebSocket, а не опитування GET-ом: одне постійне TCP-з'єднання,
 * сервер сам надсилає дані 10 разів за секунду, без заголовків HTTP щоразу.
 */
#ifndef NET_WEB_H
#define NET_WEB_H

#include "net_api.h"
#include "esp_err.h"
#include <stdint.h>

esp_err_t NetWeb_Start(const NetApi_t *api, const uint8_t *page, size_t page_len,
                       uint32_t push_period_ms);
int       NetWeb_WsClients(void);

#endif /* NET_WEB_H */
