/**
 * net_api.h — КОНТРАКТ між мережею і застосунком (Dependency Inversion).
 *
 * Мережеві модулі (вебсервер, MQTT) нічого не знають про PID, мотор чи
 * світлодіоди. Вони отримують три функції-колбеки і лише переносять байти:
 *   застосунок → мережа:  status_json()  — телеметрія у форматі JSON;
 *   мережа → застосунок:  command()      — команда від клієнта (JSON);
 *   застосунок → мережа:  next_log()     — наступний рядок журналу.
 * Той самий контракт використовують і WebSocket, і REST, і MQTT.
 */
#ifndef NET_API_H
#define NET_API_H

#include <stddef.h>

typedef struct {
    size_t (*status_json)(char *buf, size_t max);         /* повертає довжину JSON   */
    void   (*command)(const char *json, size_t len);      /* викликається з задачі мережі */
    size_t (*next_log)(char *buf, size_t max);            /* 0 = журнал порожній     */
} NetApi_t;

#endif /* NET_API_H */
