/**
 * net_logtap.h — "відвід" журналу ESP_LOGx у вебсторінку.
 *
 * esp_log_set_vprintf() дозволяє підмінити функцію друку журналу. Наша функція
 * друкує рядок як завжди (в USB/UART), а копію кладе в кільцевий буфер
 * FreeRTOS (Ringbuffer). Задача вебсервера забирає рядки звідти і шле
 * у вікно логів на сторінці. Запис у буфер — з тайм-аутом 0: якщо буфер
 * повний, рядок просто не потрапить на сторінку, але ніхто не блокується.
 */
#ifndef NET_LOGTAP_H
#define NET_LOGTAP_H

#include <stddef.h>

void   LogTap_Init(void);
size_t LogTap_Read(char *out, size_t max);   /* один рядок без '\n'; 0 = порожньо */

#endif /* NET_LOGTAP_H */
