/**
 * net_mqtt.h — НЕОБОВ'ЯЗКОВИЙ MQTT-клієнт (вмикається в menuconfig).
 *
 *   <prefix>/telemetry  ← ESP32 публікує JSON стану раз на period_ms (QoS 0)
 *   <prefix>/cmd        → ESP32 підписаний; той самий JSON команд, що й у вебі (QoS 1)
 *   <prefix>/status     ← "online" (retain) + Last Will "offline"
 *
 * Перевірка: MQTT Explorer → broker.hivemq.com:1883 → тема <prefix>/#.
 */
#ifndef NET_MQTT_H
#define NET_MQTT_H

#include "net_api.h"
#include <stdint.h>

void NetMqtt_Start(const char *broker_uri, const char *topic_prefix,
                   const NetApi_t *api, uint32_t period_ms);

#endif /* NET_MQTT_H */
