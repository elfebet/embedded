/**
 * net_wifi.h — Wi-Fi: режим STA (клієнт роутера) з запасним режимом AP.
 *
 * Логіка (див. урок про Wi-Fi і Event Loop):
 *  1) якщо в menuconfig задано SSID — пробуємо підключитися як STA;
 *  2) чекаємо на EventGroup біт CONNECTED (його ставить обробник IP_EVENT_STA_GOT_IP)
 *     або FAIL (після N невдалих спроб);
 *  3) не вийшло або SSID порожній → піднімаємо власну точку доступу (AP),
 *     і сторінка відкривається за адресою http://192.168.4.1 без роутера.
 */
#ifndef NET_WIFI_H
#define NET_WIFI_H

#include <stdint.h>

typedef enum { NET_MODE_NONE = 0, NET_MODE_STA, NET_MODE_AP } NetMode_t;

typedef struct {
    const char *sta_ssid;       /* "" → одразу AP                     */
    const char *sta_pass;
    int         sta_max_retry;  /* спроб до переходу в AP             */
    const char *ap_ssid;
    const char *ap_pass;        /* ≥ 8 символів, або "" = відкрита    */
} NetWifiConfig_t;

/* Блокує викликача до отримання IP (STA) або старту AP. Викликати з app_main. */
NetMode_t   NetWifi_Start(const NetWifiConfig_t *cfg);
NetMode_t   NetWifi_Mode(void);
const char *NetWifi_Ip(void);          /* "192.168.0.103" */
int         NetWifi_Rssi(void);        /* дБм у режимі STA, 0 у режимі AP */

#endif /* NET_WIFI_H */
