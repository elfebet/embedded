/**
 * net_mqtt.c — esp-mqtt: події через Event Loop, публікація з окремої задачі.
 */
#include "net_mqtt.h"

#include <stdio.h>
#include <string.h>
#include "mqtt_client.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "mqtt";

static esp_mqtt_client_handle_t client;
static const NetApi_t *api;
static uint32_t   period_ms;
static char       t_tel[64], t_cmd[64], t_status[64];
static volatile bool connected;

static StaticTask_t pub_tcb;
static StackType_t  pub_stack[4096];

static void on_mqtt(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg; (void)base;
    esp_mqtt_event_handle_t e = (esp_mqtt_event_handle_t)data;
    switch ((esp_mqtt_event_id_t)id) {
    case MQTT_EVENT_CONNECTED:
        connected = true;
        esp_mqtt_client_subscribe(client, t_cmd, 1);
        esp_mqtt_client_publish(client, t_status, "online", 0, 1, 1);
        ESP_LOGI(TAG, "під'єднано до брокера, підписка на %s", t_cmd);
        break;
    case MQTT_EVENT_DISCONNECTED:
        connected = false;
        ESP_LOGW(TAG, "брокер недоступний, клієнт перепідключиться сам");
        break;
    case MQTT_EVENT_DATA:
        /* Повідомлення може прийти частинами; команди короткі — беремо цілі */
        if (e->topic_len == (int)strlen(t_cmd) && strncmp(e->topic, t_cmd, e->topic_len) == 0 &&
            e->current_data_offset == 0 && e->data_len == e->total_data_len) {
            api->command(e->data, (size_t)e->data_len);
        }
        break;
    default:
        break;
    }
}

static void pub_task(void *arg)
{
    (void)arg;
    static char buf[1024];
    TickType_t last = xTaskGetTickCount();
    for (;;) {
        xTaskDelayUntil(&last, pdMS_TO_TICKS(period_ms));
        if (!connected) continue;
        size_t n = api->status_json(buf, sizeof buf);
        if (n > 0) esp_mqtt_client_publish(client, t_tel, buf, (int)n, 0, 0);
    }
}

void NetMqtt_Start(const char *broker_uri, const char *prefix, const NetApi_t *a, uint32_t period)
{
    api       = a;
    period_ms = period ? period : 1000;
    snprintf(t_tel,    sizeof t_tel,    "%s/telemetry", prefix);
    snprintf(t_cmd,    sizeof t_cmd,    "%s/cmd",       prefix);
    snprintf(t_status, sizeof t_status, "%s/status",    prefix);

    const esp_mqtt_client_config_t cfg = {
        .broker.address.uri = broker_uri,
        .session.last_will  = { .topic = t_status, .msg = "offline", .qos = 1, .retain = 1 },
    };
    client = esp_mqtt_client_init(&cfg);
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, on_mqtt, NULL);
    esp_mqtt_client_start(client);
    xTaskCreateStatic(pub_task, "mqtt_pub", sizeof pub_stack, NULL, 2, pub_stack, &pub_tcb);
    ESP_LOGI(TAG, "брокер %s, теми %s/…", broker_uri, prefix);
}
