/**
 * net_wifi.c — ініціалізація Wi-Fi через Event Loop і EventGroup.
 *
 * Порядок подій у режимі STA:
 *   WIFI_EVENT_STA_START → esp_wifi_connect()
 *   WIFI_EVENT_STA_CONNECTED
 *   IP_EVENT_STA_GOT_IP  → біт CONNECTED  ← лише тепер можна HTTP/MQTT
 *   WIFI_EVENT_STA_DISCONNECTED → повторна спроба (або біт FAIL)
 */
#include "net_wifi.h"

#include <string.h>
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"

static const char *TAG = "wifi";

#define BIT_CONNECTED  BIT0
#define BIT_FAIL       BIT1

static StaticEventGroup_t eg_buf;
static EventGroupHandle_t eg;
static int       retries;
static int       max_retry;
static bool      got_ip_once;          /* після першого успіху перепідключаємось безкінечно */
static NetMode_t mode = NET_MODE_NONE;
static char      ip_str[16] = "0.0.0.0";

/* Обробник подій. Викликається з задачі Event Loop (не з переривання),
   тому тут можна викликати esp_wifi_connect() і писати в журнал. */
static void on_event(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg;
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        if (got_ip_once || retries < max_retry) {
            retries++;
            ESP_LOGW(TAG, "зв'язок втрачено, спроба %d", retries);
            esp_wifi_connect();
        } else {
            xEventGroupSetBits(eg, BIT_FAIL);
        }
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        const ip_event_got_ip_t *e = (const ip_event_got_ip_t *)data;
        snprintf(ip_str, sizeof ip_str, IPSTR, IP2STR(&e->ip_info.ip));
        ESP_LOGI(TAG, "отримано IP (DHCP): %s", ip_str);
        retries = 0;
        got_ip_once = true;
        xEventGroupSetBits(eg, BIT_CONNECTED);
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STACONNECTED) {
        ESP_LOGI(TAG, "до точки доступу під'єднався клієнт");
    }
}

static void start_ap(const NetWifiConfig_t *cfg)
{
    wifi_config_t ap = { 0 };
    strlcpy((char *)ap.ap.ssid, cfg->ap_ssid, sizeof ap.ap.ssid);
    strlcpy((char *)ap.ap.password, cfg->ap_pass, sizeof ap.ap.password);
    ap.ap.ssid_len       = (uint8_t)strlen(cfg->ap_ssid);
    ap.ap.channel        = 6;
    ap.ap.max_connection = 4;
    ap.ap.authmode       = (strlen(cfg->ap_pass) >= 8) ? WIFI_AUTH_WPA2_PSK : WIFI_AUTH_OPEN;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &ap));
    ESP_ERROR_CHECK(esp_wifi_start());
    strlcpy(ip_str, "192.168.4.1", sizeof ip_str);     /* стандартна адреса AP в ESP-IDF */
    mode = NET_MODE_AP;
    ESP_LOGI(TAG, "режим AP: мережа \"%s\", відкрийте http://%s", cfg->ap_ssid, ip_str);
}

NetMode_t NetWifi_Start(const NetWifiConfig_t *cfg)
{
    eg = xEventGroupCreateStatic(&eg_buf);
    max_retry = cfg->sta_max_retry;

    esp_netif_create_default_wifi_sta();
    esp_netif_create_default_wifi_ap();

    const wifi_init_config_t init = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, on_event, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, on_event, NULL));

    if (cfg->sta_ssid == NULL || cfg->sta_ssid[0] == '\0') {
        ESP_LOGW(TAG, "SSID не задано в menuconfig → одразу режим AP");
        start_ap(cfg);
        return mode;
    }

    wifi_config_t sta = { 0 };
    strlcpy((char *)sta.sta.ssid, cfg->sta_ssid, sizeof sta.sta.ssid);
    strlcpy((char *)sta.sta.password, cfg->sta_pass, sizeof sta.sta.password);
    sta.sta.threshold.authmode = WIFI_AUTH_OPEN;       /* приймаємо будь-яку (WPA2/WPA3 теж) */
    sta.sta.sae_pwe_h2e        = WPA3_SAE_PWE_BOTH;    /* WPA3: обидва способи обміну ключем */
    sta.sta.pmf_cfg.capable    = true;                 /* захищені кадри керування (потрібні для WPA3) */
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &sta));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(TAG, "режим STA: підключаюсь до \"%s\"…", cfg->sta_ssid);

    /* Чекаємо ОДИН із двох бітів. Задача спить і не витрачає процесор */
    EventBits_t bits = xEventGroupWaitBits(eg, BIT_CONNECTED | BIT_FAIL,
                                           pdFALSE, pdFALSE, pdMS_TO_TICKS(20000));
    if (bits & BIT_CONNECTED) {
        mode = NET_MODE_STA;
        ESP_LOGI(TAG, "готово: відкрийте http://%s", ip_str);
        return mode;
    }

    ESP_LOGW(TAG, "до \"%s\" підключитись не вдалося → запасний режим AP", cfg->sta_ssid);
    esp_wifi_stop();
    start_ap(cfg);
    return mode;
}

NetMode_t   NetWifi_Mode(void) { return mode; }
const char *NetWifi_Ip(void)   { return ip_str; }

int NetWifi_Rssi(void)
{
    wifi_ap_record_t ap;
    if (mode == NET_MODE_STA && esp_wifi_sta_get_ap_info(&ap) == ESP_OK) return ap.rssi;
    return 0;
}
