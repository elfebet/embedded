/**
 * net_web.c — esp_http_server + WebSocket.
 *
 * Потоки:
 *  - задача httpd (створює ESP-IDF) приймає запити і кадри WebSocket;
 *  - наша задача "ws_tx" раз на push_period_ms збирає телеметрію і рядки
 *    журналу і розсилає їх усім WebSocket-клієнтам через httpd_ws_send_data()
 *    (ця функція безпечна для виклику з ІНШОЇ задачі: вона ставить роботу
 *    в чергу httpd і чекає її виконання).
 */
#include "net_web.h"

#include <string.h>
#include "esp_http_server.h"
#include "sdkconfig.h"

#if !CONFIG_HTTPD_WS_SUPPORT
#error "Увімкніть WebSocket: idf.py menuconfig → Component config → HTTP Server → WebSocket server support (або видаліть sdkconfig і зберіть заново)"
#endif
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "web";

#define WS_MAX_CLIENTS   6
#define CMD_MAX_LEN      256
#define TX_STACK_BYTES   4096
#define TX_PRIO          3
#define TX_BUF_BYTES     2048
#define LOG_LINES_PER_TX 12

static httpd_handle_t  srv;
static const NetApi_t *api;
static const uint8_t  *page_data;
static size_t          page_size;
static uint32_t        period_ms;
static volatile int    ws_clients;

static StaticTask_t tx_tcb;
static StackType_t  tx_stack[TX_STACK_BYTES];     /* у ESP-IDF розмір стеку — у БАЙТАХ */
static char         tx_buf[TX_BUF_BYTES];

/* ------------------------------- HTTP ------------------------------- */
static esp_err_t h_index(httpd_req_t *req)
{
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_set_hdr(req, "Cache-Control", "no-cache");
    return httpd_resp_send(req, (const char *)page_data, (ssize_t)page_size);
}

static esp_err_t h_status(httpd_req_t *req)
{
    static char buf[1024];                      /* лише задача httpd сюди пише */
    size_t n = api->status_json(buf, sizeof buf);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    return httpd_resp_send(req, buf, (ssize_t)n);
}

static esp_err_t h_cmd(httpd_req_t *req)
{
    char body[CMD_MAX_LEN + 1];
    if (req->content_len == 0 || req->content_len > CMD_MAX_LEN) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "body 1..256 bytes");
    }
    int got = 0;
    while (got < (int)req->content_len) {
        int r = httpd_req_recv(req, body + got, req->content_len - got);
        if (r <= 0) return ESP_FAIL;
        got += r;
    }
    body[got] = '\0';
    api->command(body, (size_t)got);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

/* ----------------------------- WebSocket ----------------------------- */
static esp_err_t h_ws(httpd_req_t *req)
{
    if (req->method == HTTP_GET) {               /* рукостискання (handshake) */
        ESP_LOGI(TAG, "WebSocket: новий клієнт (fd %d)", httpd_req_to_sockfd(req));
        return ESP_OK;
    }
    httpd_ws_frame_t f = { .type = HTTPD_WS_TYPE_TEXT };
    esp_err_t r = httpd_ws_recv_frame(req, &f, 0);       /* 1) дізнаємось довжину */
    if (r != ESP_OK) return r;
    if (f.len == 0) return ESP_OK;
    if (f.len > CMD_MAX_LEN) return ESP_FAIL;            /* завеликий кадр → закрити */

    uint8_t buf[CMD_MAX_LEN + 1];
    f.payload = buf;
    r = httpd_ws_recv_frame(req, &f, f.len);             /* 2) читаємо дані */
    if (r != ESP_OK) return r;
    buf[f.len] = '\0';
    if (f.type == HTTPD_WS_TYPE_TEXT) api->command((const char *)buf, f.len);
    return ESP_OK;
}

static void broadcast(const char *msg, size_t len)
{
    int    fds[WS_MAX_CLIENTS];
    size_t n = WS_MAX_CLIENTS;
    int    count = 0;
    if (httpd_get_client_list(srv, &n, fds) != ESP_OK) return;

    httpd_ws_frame_t f = {
        .type    = HTTPD_WS_TYPE_TEXT,
        .payload = (uint8_t *)msg,
        .len     = len,
        .final   = true,
    };
    for (size_t i = 0; i < n; i++) {
        if (httpd_ws_get_fd_info(srv, fds[i]) != HTTPD_WS_CLIENT_WEBSOCKET) continue;
        count++;
        httpd_ws_send_data(srv, fds[i], &f);
    }
    ws_clients = count;
}

/* Рядок журналу → рядок JSON: екрануємо лапки, \ і керівні символи (кольори ANSI) */
static size_t json_escape(char *dst, size_t max, const char *src)
{
    size_t o = 0;
    for (; *src && o + 7 < max; src++) {
        unsigned char c = (unsigned char)*src;
        if (c == '"' || c == '\\') { dst[o++] = '\\'; dst[o++] = (char)c; }
        else if (c == 0x1B) {                     /* ESC[0;32m … — пропускаємо */
            while (*src && *src != 'm') src++;
            if (!*src) break;
        }
        else if (c < 0x20) { dst[o++] = ' '; }
        else dst[o++] = (char)c;
    }
    dst[o] = '\0';
    return o;
}

static void ws_tx_task(void *arg)
{
    (void)arg;
    TickType_t last = xTaskGetTickCount();
    char line[168], esc[240];

    for (;;) {
        xTaskDelayUntil(&last, pdMS_TO_TICKS(period_ms));

        /* 1) телеметрія */
        size_t n = api->status_json(tx_buf, sizeof tx_buf);
        if (n > 0) broadcast(tx_buf, n);

        /* 2) пачка рядків журналу одним кадром: {"t":"log","lines":["…","…"]} */
        size_t o = (size_t)snprintf(tx_buf, sizeof tx_buf, "{\"t\":\"log\",\"lines\":[");
        int lines = 0;
        while (lines < LOG_LINES_PER_TX && api->next_log && api->next_log(line, sizeof line) > 0) {
            size_t e = json_escape(esc, sizeof esc, line);
            if (o + e + 8 >= sizeof tx_buf) break;
            o += (size_t)snprintf(tx_buf + o, sizeof tx_buf - o, "%s\"%s\"", lines ? "," : "", esc);
            lines++;
        }
        if (lines > 0) {
            o += (size_t)snprintf(tx_buf + o, sizeof tx_buf - o, "]}");
            broadcast(tx_buf, o);
        }
    }
}

esp_err_t NetWeb_Start(const NetApi_t *a, const uint8_t *page, size_t page_len, uint32_t push_period_ms)
{
    api       = a;
    page_data = page;
    page_size = page_len;
    period_ms = push_period_ms ? push_period_ms : 100;

    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.stack_size       = 6144;       /* розбір JSON у колбеку command() */
    cfg.max_open_sockets = WS_MAX_CLIENTS;
    cfg.lru_purge_enable = true;       /* нове з'єднання витісняє найстаріше */

    esp_err_t r = httpd_start(&srv, &cfg);
    if (r != ESP_OK) {
        ESP_LOGE(TAG, "не вдалося запустити HTTP-сервер: %s", esp_err_to_name(r));
        return r;
    }

    static const httpd_uri_t uris[] = {
        { .uri = "/",           .method = HTTP_GET,  .handler = h_index  },
        { .uri = "/api/status", .method = HTTP_GET,  .handler = h_status },
        { .uri = "/api/cmd",    .method = HTTP_POST, .handler = h_cmd    },
        { .uri = "/ws",         .method = HTTP_GET,  .handler = h_ws, .is_websocket = true },
    };
    for (size_t i = 0; i < sizeof uris / sizeof uris[0]; i++) {
        httpd_register_uri_handler(srv, &uris[i]);
    }

    xTaskCreateStatic(ws_tx_task, "ws_tx", TX_STACK_BYTES, NULL, TX_PRIO, tx_stack, &tx_tcb);
    ESP_LOGI(TAG, "HTTP-сервер запущено: сторінка /, WebSocket /ws, REST /api/status, /api/cmd");
    return ESP_OK;
}

int NetWeb_WsClients(void) { return ws_clients; }
