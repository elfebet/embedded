/**
 * net_logtap.c — підміна vprintf журналу + статичний кільцевий буфер.
 */
#include "net_logtap.h"

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/ringbuf.h"

#define TAP_BUF_BYTES  4096
#define TAP_LINE_MAX   160

static StaticRingbuffer_t rb_struct;
static uint8_t            rb_storage[TAP_BUF_BYTES];
static RingbufHandle_t    rb;
static vprintf_like_t     prev_vprintf;

static int tap_vprintf(const char *fmt, va_list args)
{
    va_list copy;
    va_copy(copy, args);
    int ret = prev_vprintf(fmt, args);           /* 1) як завжди — у послідовний порт */

    char line[TAP_LINE_MAX];                      /* 2) копія — у буфер для сторінки */
    int n = vsnprintf(line, sizeof line, fmt, copy);
    va_end(copy);
    if (n > 0 && rb != NULL) {
        size_t len = strnlen(line, sizeof line);
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) len--;
        if (len > 0) xRingbufferSend(rb, line, len, 0);   /* 0 = не чекати ніколи */
    }
    return ret;
}

void LogTap_Init(void)
{
    rb = xRingbufferCreateStatic(sizeof rb_storage, RINGBUF_TYPE_NOSPLIT, rb_storage, &rb_struct);
    prev_vprintf = esp_log_set_vprintf(tap_vprintf);
}

size_t LogTap_Read(char *out, size_t max)
{
    if (rb == NULL || max == 0) return 0;
    size_t len = 0;
    char *item = (char *)xRingbufferReceive(rb, &len, 0);
    if (item == NULL) return 0;
    if (len >= max) len = max - 1;
    memcpy(out, item, len);
    out[len] = '\0';
    vRingbufferReturnItem(rb, item);
    return len;
}
