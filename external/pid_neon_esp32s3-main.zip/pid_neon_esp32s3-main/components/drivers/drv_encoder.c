/**
 * drv_encoder.c — квадратурне декодування на PCNT (як у прикладі ESP-IDF rotary_encoder).
 */
#include "drv_encoder.h"
#include "esp_err.h"
#include "driver/gpio.h"

#define PCNT_LIMIT  10000

void Encoder_Init(Encoder_t *e, int gpio_a, int gpio_b, int32_t counts_per_detent, bool invert)
{
    const pcnt_unit_config_t ucfg = {
        .low_limit  = -PCNT_LIMIT,
        .high_limit =  PCNT_LIMIT,
        .flags.accum_count = 1,          /* при переповненні не губимо імпульси */
    };
    ESP_ERROR_CHECK(pcnt_new_unit(&ucfg, &e->unit));

    const pcnt_glitch_filter_config_t filt = { .max_glitch_ns = 1000 };   /* антибрязкіт */
    ESP_ERROR_CHECK(pcnt_unit_set_glitch_filter(e->unit, &filt));

    /* Канал A: фронти A, напрямок за рівнем B. Канал B: навпаки. Разом — x4 */
    pcnt_channel_handle_t ca, cb;
    const pcnt_chan_config_t cfg_a = { .edge_gpio_num = gpio_a, .level_gpio_num = gpio_b };
    const pcnt_chan_config_t cfg_b = { .edge_gpio_num = gpio_b, .level_gpio_num = gpio_a };
    ESP_ERROR_CHECK(pcnt_new_channel(e->unit, &cfg_a, &ca));
    ESP_ERROR_CHECK(pcnt_new_channel(e->unit, &cfg_b, &cb));
    ESP_ERROR_CHECK(pcnt_channel_set_edge_action(ca, PCNT_CHANNEL_EDGE_ACTION_DECREASE, PCNT_CHANNEL_EDGE_ACTION_INCREASE));
    ESP_ERROR_CHECK(pcnt_channel_set_level_action(ca, PCNT_CHANNEL_LEVEL_ACTION_KEEP, PCNT_CHANNEL_LEVEL_ACTION_INVERSE));
    ESP_ERROR_CHECK(pcnt_channel_set_edge_action(cb, PCNT_CHANNEL_EDGE_ACTION_INCREASE, PCNT_CHANNEL_EDGE_ACTION_DECREASE));
    ESP_ERROR_CHECK(pcnt_channel_set_level_action(cb, PCNT_CHANNEL_LEVEL_ACTION_KEEP, PCNT_CHANNEL_LEVEL_ACTION_INVERSE));

    /* accum_count працює лише з точками спостереження на межах */
    ESP_ERROR_CHECK(pcnt_unit_add_watch_point(e->unit,  PCNT_LIMIT));
    ESP_ERROR_CHECK(pcnt_unit_add_watch_point(e->unit, -PCNT_LIMIT));

    /* Внутрішні підтяжки на випадок, якщо модуль без власних резисторів */
    gpio_pullup_en(gpio_a);
    gpio_pullup_en(gpio_b);

    ESP_ERROR_CHECK(pcnt_unit_enable(e->unit));
    ESP_ERROR_CHECK(pcnt_unit_clear_count(e->unit));
    ESP_ERROR_CHECK(pcnt_unit_start(e->unit));

    e->last_count        = 0;
    e->remainder         = 0;
    e->counts_per_detent = counts_per_detent > 0 ? counts_per_detent : 1;
    e->invert            = invert;
}

int32_t Encoder_ReadDetents(Encoder_t *e)
{
    int now = 0;
    pcnt_unit_get_count(e->unit, &now);
    int32_t diff = (int32_t)(now - e->last_count);
    e->last_count = now;
    if (e->invert) diff = -diff;

    e->remainder += diff;
    int32_t det = e->remainder / e->counts_per_detent;   /* ділення до нуля → знак зберігається */
    e->remainder -= det * e->counts_per_detent;
    return det;
}
