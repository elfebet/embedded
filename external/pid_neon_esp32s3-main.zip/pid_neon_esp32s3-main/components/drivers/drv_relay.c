/**
 * drv_relay.c — драйвер реле.
 */
#include "drv_relay.h"

void Relay_Init(Relay_t *r, DigitalOut_t out)
{
    r->out = out;
    r->on  = false;
    DigitalOut_Init(&r->out);       /* ставить неактивний рівень ДО режиму виходу */
}

void Relay_Set(Relay_t *r, bool on)
{
    r->on = on;
    DigitalOut_Set(&r->out, on);
}

bool Relay_IsOn(const Relay_t *r)
{
    return r->on;
}
