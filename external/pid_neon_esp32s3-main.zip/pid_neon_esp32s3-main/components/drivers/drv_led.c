/**
 * drv_led.c — драйвер світлодіода: пам'ятає свій стан, щоб уміти Toggle.
 */
#include "drv_led.h"

void Led_Init(Led_t *led, DigitalOut_t out)
{
    led->out = out;
    led->on  = false;
    DigitalOut_Init(&led->out);
}

void Led_Set(Led_t *led, bool on)
{
    led->on = on;
    DigitalOut_Set(&led->out, on);
}

void Led_Toggle(Led_t *led)
{
    Led_Set(led, !led->on);
}
