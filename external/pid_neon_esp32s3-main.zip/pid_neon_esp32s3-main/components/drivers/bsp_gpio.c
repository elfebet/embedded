/**
 * bsp_gpio.c — реалізація BSP через driver/gpio.h ESP-IDF.
 */
#include "bsp_gpio.h"

void DigitalOut_Init(const DigitalOut_t *d)
{
    /* Спершу рівень, потім режим виходу: пін з'являється вже в неактивному стані */
    gpio_set_level(d->pin, d->active_low ? 1 : 0);
    const gpio_config_t cfg = {
        .pin_bit_mask = 1ULL << d->pin,
        .mode         = d->open_drain ? GPIO_MODE_OUTPUT_OD : GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&cfg));
    DigitalOut_Set(d, false);
}

void DigitalOut_Set(const DigitalOut_t *d, bool active)
{
    /* active_low: активний = 0. XOR перетворює "логічний" стан на рівень піна */
    gpio_set_level(d->pin, (active != d->active_low) ? 1 : 0);
}

void DigitalIn_Init(const DigitalIn_t *d)
{
    const gpio_config_t cfg = {
        .pin_bit_mask = 1ULL << d->pin,
        .mode         = GPIO_MODE_INPUT,
        .pull_up_en   = d->pull_up ? GPIO_PULLUP_ENABLE : GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&cfg));
}

bool DigitalIn_IsActive(const DigitalIn_t *d)
{
    return (gpio_get_level(d->pin) != 0) != d->active_low;
}
