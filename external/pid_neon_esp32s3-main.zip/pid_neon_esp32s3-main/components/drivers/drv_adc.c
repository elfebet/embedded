/**
 * drv_adc.c — ADC1 oneshot + калібрування curve fitting.
 */
#include "drv_adc.h"
#include "esp_adc/adc_cali_scheme.h"
#include "esp_log.h"

static const char *TAG = "adc";

void AdcIn_Init(AdcIn_t *a, int gpio, uint8_t oversample)
{
    adc_unit_t unit_id;
    ESP_ERROR_CHECK(adc_oneshot_io_to_channel(gpio, &unit_id, &a->channel));   /* GPIO → (АЦП, канал) */
    if (unit_id != ADC_UNIT_1) {
        ESP_LOGE(TAG, "GPIO%d належить ADC2 — він конфліктує з Wi-Fi. Оберіть GPIO1…10", gpio);
    }

    const adc_oneshot_unit_init_cfg_t ucfg = { .unit_id = unit_id };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&ucfg, &a->unit));

    const adc_oneshot_chan_cfg_t ccfg = {
        .atten    = ADC_ATTEN_DB_12,             /* 0…~3,1 В */
        .bitwidth = ADC_BITWIDTH_12,
    };
    ESP_ERROR_CHECK(adc_oneshot_config_channel(a->unit, a->channel, &ccfg));

    const adc_cali_curve_fitting_config_t cal = {
        .unit_id  = unit_id,
        .chan     = a->channel,
        .atten    = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_12,
    };
    a->cali_ok = (adc_cali_create_scheme_curve_fitting(&cal, &a->cali) == ESP_OK);
    ESP_LOGI(TAG, "GPIO%d → ADC%d CH%d, калібрування: %s", gpio, unit_id + 1, a->channel,
             a->cali_ok ? "curve fitting (eFuse)" : "НЕМАЄ — лінійне наближення");

    a->oversample = oversample ? oversample : 1;
    a->last_raw   = 0;
}

uint32_t AdcIn_ReadMv(AdcIn_t *a)
{
    int sum = 0, raw = 0;
    for (uint8_t i = 0; i < a->oversample; i++) {
        if (adc_oneshot_read(a->unit, a->channel, &raw) == ESP_OK) sum += raw;
    }
    a->last_raw = sum / a->oversample;

    int mv = 0;
    if (a->cali_ok && adc_cali_raw_to_voltage(a->cali, a->last_raw, &mv) == ESP_OK) {
        return (uint32_t)mv;
    }
    return (uint32_t)(a->last_raw * 3100 / 4095);   /* запасний варіант без калібрування */
}
