/**
 * drv_motor_relay.c — мотор на двох реле.
 *
 * Захист "в глибину" (defense in depth):
 *  1) автомат станів (app_motor_fsm) витримує паузу CFG_DEADTIME_MS між напрямками;
 *  2) цей драйвер додатково гарантує "break-before-make": спершу вимикає
 *     протилежне реле, і лише потім вмикає потрібне.
 * Навіть якщо обидва реле ввімкнуться — у цій схемі це гальмування, а не КЗ.
 */
#include "drv_motor_relay.h"

static void relay_motor_stop(void *self)
{
    MotorRelay_t *m = (MotorRelay_t *)self;
    Relay_Set(m->relay_cw,  false);
    Relay_Set(m->relay_ccw, false);
}

static void relay_motor_run(void *self, MotorDir_t dir)
{
    MotorRelay_t *m = (MotorRelay_t *)self;
    Relay_t *on  = (dir == MOTOR_DIR_CW) ? m->relay_cw  : m->relay_ccw;
    Relay_t *off = (dir == MOTOR_DIR_CW) ? m->relay_ccw : m->relay_cw;

    Relay_Set(off, false);      /* break ... */
    Relay_Set(on,  true);       /* ... before make */
}

static const MotorOps_t RELAY_MOTOR_OPS = {
    .run  = relay_motor_run,
    .stop = relay_motor_stop,
};

void MotorRelay_Init(MotorRelay_t *m, Relay_t *relay_cw, Relay_t *relay_ccw)
{
    m->relay_cw  = relay_cw;
    m->relay_ccw = relay_ccw;
    relay_motor_stop(m);
}

Motor_t MotorRelay_AsMotor(MotorRelay_t *m)
{
    Motor_t motor = { .ops = &RELAY_MOTOR_OPS, .self = m };
    return motor;
}
