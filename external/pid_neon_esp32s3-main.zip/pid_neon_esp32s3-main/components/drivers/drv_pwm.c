/**
 * drv_pwm.c — LEDC у режимі LOW_SPEED (у ESP32-S3 інших немає).
 */
#include "drv_pwm.h"
#include "esp_err.h"

#define PWM_RES      LEDC_TIMER_10_BIT
#define PWM_RES_BITS 10u

void Pwm_Init(Pwm_t *p, int gpio, uint32_t freq_hz, ledc_timer_t timer, ledc_channel_t ch)
{
    const ledc_timer_config_t t = {
        .speed_mode      = LEDC_LOW_SPEED_MODE,
        .duty_resolution = PWM_RES,
        .timer_num       = timer,
        .freq_hz         = freq_hz,          /* 80 МГц / 1024 / 20 кГц ≈ 3,9 — дільник вміщається */
        .clk_cfg         = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&t));

    const ledc_channel_config_t c = {
        .gpio_num   = gpio,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel    = ch,
        .timer_sel  = timer,
        .duty       = 0,                     /* старт із 0 % — конденсатори розряджені */
        .hpoint     = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&c));

    p->channel   = ch;
    p->max_duty  = (1u << PWM_RES_BITS) - 1u;
    p->last_duty = 0;
}

void Pwm_SetDuty(Pwm_t *p, float duty01)
{
    if (duty01 < 0.0f) duty01 = 0.0f;
    if (duty01 > 1.0f) duty01 = 1.0f;
    uint32_t d = (uint32_t)(duty01 * (float)p->max_duty + 0.5f);
    if (d == p->last_duty) return;           /* не смикаємо периферію без потреби */
    p->last_duty = d;
    /* set + update: нове значення застосовується з початку наступного періоду ШІМ
       (аналог preload на STM32 — без "обрізаних" імпульсів) */
    ledc_set_duty(LEDC_LOW_SPEED_MODE, p->channel, d);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, p->channel);
}
