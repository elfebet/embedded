/**
 * drv_button.c — антибрязкіт лічильником відліків.
 */
#include "drv_button.h"

void Button_Init(Button_t *b, DigitalIn_t in, uint8_t threshold)
{
    b->in        = in;
    b->threshold = threshold ? threshold : 1;
    b->count     = 0;
    DigitalIn_Init(&b->in);
    b->stable    = DigitalIn_IsActive(&b->in);
}

bool Button_PollPressed(Button_t *b)
{
    bool raw = DigitalIn_IsActive(&b->in);

    if (raw == b->stable) {          /* нічого не змінилось — скидаємо лічильник */
        b->count = 0;
        return false;
    }
    if (++b->count < b->threshold) { /* зміна ще не підтверджена */
        return false;
    }
    b->count  = 0;
    b->stable = raw;
    return raw;                      /* true лише на фронті "натиснули" */
}
