/**
 * bsp_gpio.h — шар BSP (Board Support Package): цифрові входи/виходи ESP32-S3.
 *
 * Той самий інтерфейс, що й у версії для STM32 — змінився лише тип піна:
 * там була пара (GPIO_TypeDef*, uint16_t), тут — один номер gpio_num_t.
 * Завдяки цьому drv_led.c, drv_relay.c, drv_button.c перенесені БЕЗ ЗМІН.
 * Патерн: Adapter (ховає драйвер ESP-IDF driver/gpio.h за простим інтерфейсом).
 */
#ifndef BSP_GPIO_H
#define BSP_GPIO_H

#include "driver/gpio.h"
#include <stdbool.h>

typedef struct {
    gpio_num_t pin;
    bool       active_low;   /* true: "активний" = логічний 0 на піні              */
    bool       open_drain;   /* true: "неактивний" = пін відпущено (high-Z)         */
} DigitalOut_t;

typedef struct {
    gpio_num_t pin;
    bool       active_low;   /* кнопка на GND з підтяжкою: натиснута = 0           */
    bool       pull_up;      /* увімкнути внутрішню підтяжку до 3,3 В               */
} DigitalIn_t;

/* Налаштовує пін і ОДРАЗУ ставить неактивний рівень (реле не "клацне" при старті) */
void DigitalOut_Init(const DigitalOut_t *d);
void DigitalOut_Set (const DigitalOut_t *d, bool active);

void DigitalIn_Init (const DigitalIn_t *d);
bool DigitalIn_IsActive(const DigitalIn_t *d);

#endif /* BSP_GPIO_H */
