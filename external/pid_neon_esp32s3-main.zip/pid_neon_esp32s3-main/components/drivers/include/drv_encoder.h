/**
 * drv_encoder.h — фізичний енкодер KY-040 на лічильнику імпульсів PCNT.
 *
 * На STM32 квадратурний сигнал рахував TIM4 в Encoder Mode. У ESP32 для цього
 * є окрема периферія PCNT (Pulse Counter): два канали, кожен рахує фронти
 * одного сигналу залежно від рівня іншого → повне квадратурне декодування x4
 * апаратно, без переривань на кожен імпульс. Апаратний фільтр прибирає брязкіт.
 *
 * Енкодер НЕОБОВ'ЯЗКОВИЙ: у цій версії уставку задає повзунок на вебсторінці
 * ("віртуальний енкодер"). Якщо KY-040 під'єднаний — працюють обидва.
 */
#ifndef DRV_ENCODER_H
#define DRV_ENCODER_H

#include "driver/pulse_cnt.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    pcnt_unit_handle_t unit;
    int      last_count;
    int32_t  remainder;           /* імпульси, що ще не склали повне клацання */
    int32_t  counts_per_detent;
    bool     invert;
} Encoder_t;

void    Encoder_Init(Encoder_t *e, int gpio_a, int gpio_b, int32_t counts_per_detent, bool invert);
int32_t Encoder_ReadDetents(Encoder_t *e);    /* >0 за годинниковою, <0 проти, 0 — стоїть */

#endif /* DRV_ENCODER_H */
