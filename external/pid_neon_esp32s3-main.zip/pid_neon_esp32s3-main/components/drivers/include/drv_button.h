/**
 * drv_button.h — кнопка з програмним антибрязкотом (debounce).
 *
 * Механічні контакти "брязкають" 1–10 мс: одне натискання дає десяток
 * перемикань. Драйвер вважає стан змінившимся, лише коли N відліків підряд
 * (кожні 10 мс) однакові.
 */
#ifndef DRV_BUTTON_H
#define DRV_BUTTON_H

#include "bsp_gpio.h"
#include <stdint.h>

typedef struct {
    DigitalIn_t in;
    uint8_t     threshold;   /* N однакових відліків                */
    uint8_t     count;       /* скільки відліків поспіль відрізняються */
    bool        stable;      /* підтверджений стан: true = натиснута */
} Button_t;

void Button_Init(Button_t *b, DigitalIn_t in, uint8_t threshold);

/* Викликати періодично. Повертає true ОДИН раз — у момент натискання. */
bool Button_PollPressed(Button_t *b);

#endif /* DRV_BUTTON_H */
