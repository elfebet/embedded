/**
 * drv_adc.h — вхід регулятора: АЦП ESP32-S3 (oneshot) + калібрування.
 *
 * Відмінності від STM32:
 *  - АЦП ESP32 нелінійний, тому напругу рахуємо НЕ як raw·3300/4095, а через
 *    заводське калібрування eFuse (схема curve fitting) → точність ~±10 мВ;
 *  - використовуємо ADC1: ADC2 зайнятий Wi-Fi-радіо, коли Wi-Fi увімкнено;
 *  - атенюатор 12 дБ → діапазон вимірювання ≈ 0…3,1 В.
 * Оверсемплінг: N відліків усереднюються → шум падає в √N разів.
 */
#ifndef DRV_ADC_H
#define DRV_ADC_H

#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    adc_oneshot_unit_handle_t unit;
    adc_cali_handle_t         cali;
    adc_channel_t             channel;
    uint8_t                   oversample;
    bool                      cali_ok;
    int                       last_raw;   /* сире значення 0…4095 (телеметрія) */
} AdcIn_t;

void     AdcIn_Init(AdcIn_t *a, int gpio, uint8_t oversample);
uint32_t AdcIn_ReadMv(AdcIn_t *a);        /* усереднена напруга, мВ */

#endif /* DRV_ADC_H */
