/**
 * drv_pwm.h — ШІМ-вихід регулятора на периферії LEDC ESP32-S3.
 *
 * На STM32 це був TIM3 CH1 (PSC/ARR). Тут — LEDC (LED Controller): у ESP32
 * саме він робить звичайний ШІМ. Частота 20 кГц, роздільність 10 біт
 * (1024 рівні, крок 3,2 мВ на виході RC-кола).
 * Інтерфейс Pwm_SetDuty(0..1) — такий самий, як у STM32-версії, тому
 * задача регулятора про LEDC не знає.
 */
#ifndef DRV_PWM_H
#define DRV_PWM_H

#include "driver/ledc.h"
#include <stdint.h>

typedef struct {
    ledc_channel_t channel;
    uint32_t       max_duty;     /* (1 << біт) − 1 */
    uint32_t       last_duty;    /* останнє записане значення (телеметрія) */
} Pwm_t;

void  Pwm_Init(Pwm_t *p, int gpio, uint32_t freq_hz, ledc_timer_t timer, ledc_channel_t ch);
void  Pwm_SetDuty(Pwm_t *p, float duty01);   /* 0.0 … 1.0 */

#endif /* DRV_PWM_H */
