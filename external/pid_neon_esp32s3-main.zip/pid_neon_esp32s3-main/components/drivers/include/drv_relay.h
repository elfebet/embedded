/**
 * drv_relay.h — драйвер модуля реле SRD-05VDC.
 *
 * Шар: драйвери. Полярність (Low/High trigger) задається при створенні
 * через DigitalOut_t — сам драйвер оперує лише "увімкнено/вимкнено".
 */
#ifndef DRV_RELAY_H
#define DRV_RELAY_H

#include "bsp_gpio.h"

typedef struct {
    DigitalOut_t out;
    bool         on;
} Relay_t;

void Relay_Init (Relay_t *r, DigitalOut_t out);   /* після Init реле гарантовано вимкнене */
void Relay_Set  (Relay_t *r, bool on);
bool Relay_IsOn (const Relay_t *r);

#endif /* DRV_RELAY_H */
