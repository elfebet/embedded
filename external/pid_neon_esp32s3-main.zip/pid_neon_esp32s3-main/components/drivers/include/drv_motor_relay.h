/**
 * drv_motor_relay.h — реалізація інтерфейсу Motor_t на двох реле
 * ("H-міст на реле": COM1/COM2 — дроти мотора, NO — +5 В, NC — GND).
 */
#ifndef DRV_MOTOR_RELAY_H
#define DRV_MOTOR_RELAY_H

#include "drv_motor.h"
#include "drv_relay.h"

typedef struct {
    Relay_t *relay_cw;    /* реле 1: увімкнене → мотор за годинниковою */
    Relay_t *relay_ccw;   /* реле 2: увімкнене → мотор проти           */
} MotorRelay_t;

void    MotorRelay_Init(MotorRelay_t *m, Relay_t *relay_cw, Relay_t *relay_ccw);
Motor_t MotorRelay_AsMotor(MotorRelay_t *m);   /* "приведення" до інтерфейсу */

#endif /* DRV_MOTOR_RELAY_H */
