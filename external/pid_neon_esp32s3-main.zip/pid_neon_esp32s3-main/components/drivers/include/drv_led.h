/**
 * drv_led.h — драйвер світлодіода.
 *
 * Шар: драйвери. Знає лише про DigitalOut_t (BSP), не про HAL чи ESP-IDF.
 */
#ifndef DRV_LED_H
#define DRV_LED_H

#include "bsp_gpio.h"

typedef struct {
    DigitalOut_t out;
    bool         on;
} Led_t;

void Led_Init  (Led_t *led, DigitalOut_t out);
void Led_Set   (Led_t *led, bool on);
void Led_Toggle(Led_t *led);

#endif /* DRV_LED_H */
