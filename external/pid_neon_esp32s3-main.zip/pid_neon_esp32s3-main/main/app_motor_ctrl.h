/**
 * app_motor_ctrl.h — контролер мотора як "активний об'єкт" (патерн Active Object).
 *
 * Активний об'єкт = власна задача FreeRTOS + власна черга подій + приватний стан.
 * Модуль сам підписується на шину (TOPIC_ENCODER_STEP, TOPIC_BUTTON) і кладе
 * отримані події у свою чергу. Інші модулі мотор напряму не викликають.
 * Усі рішення приймає одна задача, послідовно, по одній події.
 *
 * Що це дає:
 *  - немає гонок даних: стан автомата змінює лише одна задача;
 *  - не потрібні м'ютекси → неможливий deadlock та інверсія пріоритетів;
 *  - реле фізично керує рівно одна задача ("єдиний власник ресурсу").
 */
#ifndef APP_MOTOR_CTRL_H
#define APP_MOTOR_CTRL_H

#include "app_motor_fsm.h"
#include <stdbool.h>

void         MotorCtrl_Init(Motor_t motor);      /* створює чергу і задачу; до старту ОС */
bool         MotorCtrl_Post(MotorEvent_t ev);    /* з будь-якої задачі, не блокує        */
MotorState_t MotorCtrl_GetState(void);           /* для діагностики (атомарне читання)   */
uint32_t     MotorCtrl_DroppedEvents(void);      /* скільки подій загубилось (черга повна) */

#endif /* APP_MOTOR_CTRL_H */
