/**
 * app_indicator.h — світлодіоди як підписник шини подій (Observer).
 *   червоний = мотор RUN_CW, синій = RUN_CCW;
 *   "серцебиття" (якщо є): швидко — перехідний процес, повільно — вийшли на уставку.
 */
#ifndef APP_INDICATOR_H
#define APP_INDICATOR_H

#include "drv_led.h"

void Indicator_Init(Led_t *red, Led_t *blue, Led_t *heartbeat /* може бути NULL */);

#endif /* APP_INDICATOR_H */
