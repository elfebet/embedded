/**
 * app.c — КОРІНЬ КОМПОЗИЦІЇ (Composition Root) + Dependency Injection.
 *
 * Єдине місце, де створюються всі об'єкти і з'єднуються модулі — як і на STM32.
 * Порівняйте з STM32-версією: відрізняються лише рядки ініціалізації
 * драйверів (номери GPIO замість хендлів HAL). Усі app_* і pidcore — ті самі.
 *
 *   KY-040 ─┐                                   ┌─► app_motor_ctrl ─► FSM ─► реле
 *   BOOT   ─┼─► app_input ─┐                     │        │ TOPIC_MOTOR_STATE
 *           │               ├─► ШИНА ПОДІЙ ──────┤        ▼
 *   сторінка/REST/MQTT ─► app_remote ─┘          │   app_indicator ─► LED
 *   (повзунок = віртуальний енкодер)             └─► app_regulator ─► PID ─► LEDC ─► RC ─► ADC
 */
#include "app.h"
#include "app_config.h"

#include "bsp_gpio.h"
#include "drv_led.h"
#include "drv_relay.h"
#include "drv_motor_relay.h"
#include "drv_encoder.h"
#include "drv_button.h"
#include "drv_pwm.h"
#include "drv_adc.h"

#include "app_motor_ctrl.h"
#include "app_input.h"
#include "app_indicator.h"
#include "app_regulator.h"

static Relay_t      relay_cw, relay_ccw;
static MotorRelay_t motor_relay;
static Led_t        led_red, led_blue, led_heart;
static Encoder_t    encoder;
static Button_t     button;
static Pwm_t        pwm;
static AdcIn_t      adc;

void App_Init(void)
{
    /* 1) РЕЛЕ — першими: мотор гарантовано вимкнений */
    const bool active_low = (CFG_RELAY_ACTIVE_LOW != 0);
    const bool od         = (CFG_RELAY_OPEN_DRAIN != 0);
    Relay_Init(&relay_cw,  (DigitalOut_t){ CFG_RELAY_CW_GPIO,  active_low, od });
    Relay_Init(&relay_ccw, (DigitalOut_t){ CFG_RELAY_CCW_GPIO, active_low, od });
    MotorRelay_Init(&motor_relay, &relay_cw, &relay_ccw);

    /* 2) СВІТЛОДІОДИ (анодом через 220–330 Ом на GPIO, катодом на GND) */
    Led_Init(&led_red,  (DigitalOut_t){ CFG_LED_RED_GPIO,  false, false });
    Led_Init(&led_blue, (DigitalOut_t){ CFG_LED_BLUE_GPIO, false, false });
    Led_t *heart = NULL;
#if CFG_LED_HEART_GPIO >= 0
    Led_Init(&led_heart, (DigitalOut_t){ CFG_LED_HEART_GPIO, false, false });
    heart = &led_heart;
#else
    (void)led_heart;
#endif

    /* 3) ВХОДИ */
    Encoder_t *enc = NULL;
#if CFG_ENC_ENABLE
    Encoder_Init(&encoder, CFG_ENC_A_GPIO, CFG_ENC_B_GPIO, CFG_ENC_COUNTS_PER_DETENT, CFG_ENC_INVERT != 0);
    enc = &encoder;
#else
    (void)encoder;
#endif
    Button_Init(&button, (DigitalIn_t){ CFG_BUTTON_GPIO, true, true }, CFG_BUTTON_DEBOUNCE_N);

    /* 4) ВИХІД І ВХІД РЕГУЛЯТОРА */
    Pwm_Init(&pwm, CFG_PWM_GPIO, CFG_PWM_FREQ_HZ, LEDC_TIMER_0, LEDC_CHANNEL_0);
    AdcIn_Init(&adc, CFG_ADC_GPIO, CFG_REG_ADC_OVERSAMPLE);

    /* 5) З'ЄДНАТИ МОДУЛІ: спершу підписники, останнім — видавець */
    Indicator_Init(&led_red, &led_blue, heart);
    MotorCtrl_Init(MotorRelay_AsMotor(&motor_relay));
    Regulator_Init(&pwm, &adc);
    Input_Init(enc, &button);
}
