/**
 * app_input.h — фізичні входи: кнопка BOOT і (необов'язково) енкодер KY-040.
 * Публікують ті самі події, що й повзунок на сторінці → решта системи не
 * бачить різниці між "залізним" і "віртуальним" енкодером.
 */
#ifndef APP_INPUT_H
#define APP_INPUT_H

#include "drv_encoder.h"
#include "drv_button.h"

void Input_Init(Encoder_t *encoder /* може бути NULL */, Button_t *button);

#endif /* APP_INPUT_H */
