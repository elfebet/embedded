/**
 * app_config.h — УСІ налаштування проєкту в одному місці (ESP32-S3).
 *
 * Логіка та сама, що й на STM32; змінилися лише піни і пріоритети.
 * Мережеві параметри (SSID, пароль, MQTT) — у menuconfig: idf.py menuconfig →
 * "NEON PID: мережа".
 */
#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/* ============================ ПІНИ ESP32-S3 ============================
 * Уникаємо: GPIO0/3/45/46 (strapping) для виходів, GPIO19/20 (USB),
 * GPIO26…37 (flash/PSRAM на модулях N8R8/N16R8).                       */
#define CFG_PWM_GPIO          4     /* ШІМ → RC-коло (на STM32 було PA6)          */
#define CFG_ADC_GPIO          5     /* вихід RC-кола → ADC1_CH4 (на STM32 — PA1)  */
#define CFG_LED_RED_GPIO      15    /* червоний: мотор за годинниковою            */
#define CFG_LED_BLUE_GPIO     16    /* синій: мотор проти                         */
#define CFG_LED_HEART_GPIO    (-1)  /* "серцебиття"; −1 = немає (на DevKitC LED адресний) */
#define CFG_RELAY_CW_GPIO     17    /* реле 1 (IN1)                               */
#define CFG_RELAY_CCW_GPIO    18    /* реле 2 (IN2)                               */
#define CFG_BUTTON_GPIO       0     /* кнопка BOOT на платі: STOP + уставка 0     */
#define CFG_ENC_A_GPIO        6     /* KY-040 CLK (необов'язково)                 */
#define CFG_ENC_B_GPIO        7     /* KY-040 DT  (необов'язково)                 */

/* ============================== РЕЛЕ ==============================
 * УВАГА: піни ESP32-S3 НЕ толерантні до 5 В (на відміну від STM32 FT-пінів),
 * тому open-drain з підтяжкою модуля до 5 В тут НЕ використовуємо.
 * Push-pull 3,3 В: для більшості модулів Low-trigger цього досить; якщо реле
 * не відпускає — див. README, розділ "Реле і 3,3 В".                     */
#define CFG_RELAY_ACTIVE_LOW  1
#define CFG_RELAY_OPEN_DRAIN  0

/* ============================ ЕНКОДЕР ============================ */
#define CFG_ENC_ENABLE             1
#define CFG_ENC_COUNTS_PER_DETENT  4
#define CFG_ENC_INVERT             0
#define CFG_BUTTON_DEBOUNCE_N      3

/* ============================== МОТОР ============================== */
#define CFG_DEADTIME_MS       150   /* пауза перед реверсом                        */
#define CFG_IDLE_TIMEOUT_MS   600   /* зупинка, якщо уставку не змінюють           */
#define CFG_CTRL_TICK_MS      10

/* ============================ РЕГУЛЯТОР ============================ */
#define CFG_REG_PERIOD_MS       10     /* Ts = 10 мс                                 */
#define CFG_REG_ADC_OVERSAMPLE  8
#define CFG_PWM_FREQ_HZ         20000

#define CFG_PID_KP            2.0f
#define CFG_PID_KI            3.0f
#define CFG_PID_KD            0.2f
#define CFG_PID_DFILT_TAU_S   0.02f

#define CFG_SP_STEP_MV        100    /* одне клацання = 100 мВ                    */
#define CFG_SP_MIN_MV         0
#define CFG_SP_MAX_MV         2900   /* АЦП ESP32-S3 з атенюатором 12 дБ ≈ до 3,1 В */
#define CFG_SP_INITIAL_MV     1500

#define CFG_SETTLED_BAND_MV   30
#define CFG_SETTLED_TIME_MS   300

/* ============================ ТЕЛЕМЕТРІЯ ============================ */
#define CFG_WS_PUSH_MS        100    /* сторінка: 10 кадрів/с                     */
#define CFG_LOG_PERIOD_MS     500    /* рядок g_reg у журнал: 2 рази/с             */
#define CFG_HEARTBEAT_MS      500

/* ===================== FreeRTOS: пріоритети і ядра =====================
 * ESP32-S3 має ДВА ядра. Wi-Fi і TCP/IP живуть на ядрі 0 (PRO_CPU),
 * тож задачі реального часу закріплюємо на ядрі 1 (APP_CPU) — мережа
 * не зможе "вкрасти" в них процесор. Пріоритети — Rate Monotonic:
 * коротший період → вищий пріоритет.                                   */
#define CFG_RT_CORE             1
#define CFG_PRIO_REGULATOR      10   /* 10 мс                                    */
#define CFG_PRIO_MOTOR_CTRL     9
#define CFG_PRIO_INPUT          8
#define CFG_PRIO_TLOG           2    /* журнал — найнижчий: не важливо, якщо запізниться */

#endif /* APP_CONFIG_H */
