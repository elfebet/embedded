/**
 * app_motor_ctrl.c — задача-власник мотора (Active Object), порт з STM32.
 *
 * Зміни порівняно з STM32: pinned-задача на ядрі 1, стек у байтах, і одна
 * подія MEV_STEP_* на одну публікацію (повзунок може "стрибнути" на 20 кроків
 * за раз — автомату досить знати напрямок, а не кількість кроків).
 */
#include "app_motor_ctrl.h"
#include "app_config.h"
#include "svc_event_bus.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_log.h"

static const char *TAG = "motor";

#define CTRL_STACK_BYTES  3072u
#define CTRL_QUEUE_LEN    16u

static StaticTask_t  tcb;
static StackType_t   stack[CTRL_STACK_BYTES];
static StaticQueue_t qcb;
static uint8_t       qbuf[CTRL_QUEUE_LEN * sizeof(MotorEvent_t)];
static QueueHandle_t queue;

static MotorFsm_t            fsm;
static volatile MotorState_t published_state = MS_IDLE;
static volatile uint32_t     dropped;

static inline uint32_t now_ms(void)
{
    return (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);
}

/* --------- підписки на шину: виконуються в контексті задачі-видавця --------- */
static void on_encoder(void *ctx, BusTopic_t t, int32_t steps)
{
    (void)ctx; (void)t;
    if (steps != 0) MotorCtrl_Post(steps > 0 ? MEV_STEP_CW : MEV_STEP_CCW);
}

static void on_button(void *ctx, BusTopic_t t, int32_t v)
{
    (void)ctx; (void)t; (void)v;
    MotorCtrl_Post(MEV_STOP);
}

static void on_fsm_state(void *ctx, MotorState_t s)
{
    (void)ctx;
    published_state = s;
    ESP_LOGI(TAG, "стан → %s", MotorFsm_StateName(s));   /* задача мотора, не ISR — друк допустимий */
    EventBus_Publish(TOPIC_MOTOR_STATE, (int32_t)s);
}

static void MotorCtrlTask(void *arg)
{
    (void)arg;
    MotorEvent_t ev;
    for (;;) {
        if (xQueueReceive(queue, &ev, pdMS_TO_TICKS(CFG_CTRL_TICK_MS)) == pdTRUE) {
            MotorFsm_Dispatch(&fsm, ev, now_ms());
        }
        MotorFsm_Dispatch(&fsm, MEV_TICK, now_ms());
    }
}

void MotorCtrl_Init(Motor_t motor)
{
    const MotorFsmConfig_t cfg = {
        .deadtime_ms     = CFG_DEADTIME_MS,
        .idle_timeout_ms = CFG_IDLE_TIMEOUT_MS,
    };
    MotorFsm_Init(&fsm, &cfg, motor, on_fsm_state, NULL, now_ms());

    queue = xQueueCreateStatic(CTRL_QUEUE_LEN, sizeof(MotorEvent_t), qbuf, &qcb);
    bool ok = EventBus_Subscribe(TOPIC_ENCODER_STEP, on_encoder, NULL) &&
              EventBus_Subscribe(TOPIC_BUTTON,       on_button,  NULL);
    TaskHandle_t h = xTaskCreateStaticPinnedToCore(MotorCtrlTask, "motor", CTRL_STACK_BYTES, NULL,
                                                   CFG_PRIO_MOTOR_CTRL, stack, &tcb, CFG_RT_CORE);
    configASSERT(queue != NULL && ok && h != NULL);
    (void)ok; (void)h;
}

bool MotorCtrl_Post(MotorEvent_t ev)
{
    if (xQueueSend(queue, &ev, 0) == pdTRUE) return true;   /* відправник не блокується */
    dropped++;
    return false;
}

MotorState_t MotorCtrl_GetState(void)      { return published_state; }
uint32_t     MotorCtrl_DroppedEvents(void) { return dropped; }
