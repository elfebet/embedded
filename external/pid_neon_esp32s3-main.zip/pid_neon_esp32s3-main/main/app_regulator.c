/**
 * app_regulator.c — задача PID-регулятора (порт з STM32).
 *
 * Правило реального часу: задача НІКОЛИ не чекає ні на що, крім свого
 * таймера. Команди з черги — з тайм-аутом 0, журнал не друкує (друк у UART
 * повільний — ним займається окрема задача з низьким пріоритетом).
 *
 * Що змінилося порівняно з STM32:
 *  - DWT->CYCCNT → esp_timer_get_time() (мкс від старту);
 *  - xTaskCreateStatic → xTaskCreateStaticPinnedToCore (ядро 1);
 *  - vTaskDelayUntil → xTaskDelayUntil (повертає pdFALSE, якщо такт запізнився);
 *  - телеметрія пишеться під portMUX (ESP32 двоядерний: звичайна заборона
 *    переривань на одному ядрі не захищає від іншого ядра).
 */
#include "app_regulator.h"
#include "app_config.h"
#include "alg_pid.h"
#include "svc_event_bus.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_timer.h"
#include <stdlib.h>
#include <string.h>

typedef enum { RCMD_SP_DELTA, RCMD_SP_SET } RegCmdType_t;
typedef struct { RegCmdType_t type; int32_t value_mv; } RegCmd_t;

#define REG_STACK_BYTES  4096u
#define REG_QUEUE_LEN    16u

static StaticTask_t  tcb;
static StackType_t   stack[REG_STACK_BYTES];
static StaticQueue_t qcb;
static uint8_t       qbuf[REG_QUEUE_LEN * sizeof(RegCmd_t)];
static QueueHandle_t queue;

static Pwm_t   *pwm;
static AdcIn_t *adc;

static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
static volatile bool reset_stats_req;

volatile RegStatus_t g_reg;
volatile PidTuning_t g_pid_tuning = { CFG_PID_KP, CFG_PID_KI, CFG_PID_KD };

/* ------------------- підписки на шину подій (Observer) ------------------- */
static void on_encoder(void *ctx, BusTopic_t t, int32_t steps)
{
    (void)ctx; (void)t;
    RegCmd_t c = { RCMD_SP_DELTA, steps * CFG_SP_STEP_MV };
    xQueueSend(queue, &c, 0);
}

static void on_button(void *ctx, BusTopic_t t, int32_t v)
{
    (void)ctx; (void)t; (void)v;
    RegCmd_t c = { RCMD_SP_SET, CFG_SP_MIN_MV };
    xQueueSend(queue, &c, 0);
}

static int32_t clamp_sp(int32_t mv)
{
    if (mv < CFG_SP_MIN_MV) return CFG_SP_MIN_MV;
    if (mv > CFG_SP_MAX_MV) return CFG_SP_MAX_MV;
    return mv;
}

/* ----------------- автоматичні показники якості перехідного процесу ----------------- */
typedef struct {
    int32_t  start_mv, target_mv, peak_mv;
    uint32_t t_step_ms;
    bool     active;
} StepMetrics_t;

static void metrics_new_step(StepMetrics_t *m, int32_t from, int32_t to, uint32_t now)
{
    m->start_mv  = from;
    m->target_mv = to;
    m->peak_mv   = from;
    m->t_step_ms = now;
    m->active    = true;
}

/* ------------------------------ сама задача ------------------------------ */
static void RegulatorTask(void *arg)
{
    (void)arg;
    PID_Controller_t pid;
    PidTuning_t applied = { CFG_PID_KP, CFG_PID_KI, CFG_PID_KD };
    PID_Init(&pid, applied.kp, applied.ki, applied.kd,
             CFG_REG_PERIOD_MS / 1000.0f, CFG_PID_DFILT_TAU_S, 0.0f, 1.0f);

    int32_t    sp_mv   = CFG_SP_INITIAL_MV;
    bool       settled = false, in_band = false;
    uint32_t   in_band_since = 0;
    float      overshoot = 0.0f;
    int32_t    settle_ms = -1;
    uint32_t   exec_max = 0, overruns = 0;
    StepMetrics_t sm = { 0 };
    metrics_new_step(&sm, 0, sp_mv, 0);

    const TickType_t period = pdMS_TO_TICKS(CFG_REG_PERIOD_MS);
    TickType_t last = xTaskGetTickCount();

    for (;;) {
        if (xTaskDelayUntil(&last, period) == pdFALSE) overruns++;   /* такт запізнився */
        const int64_t  t0  = esp_timer_get_time();
        const uint32_t now = (uint32_t)(t0 / 1000);

        if (reset_stats_req) { reset_stats_req = false; exec_max = 0; overruns = 0; }

        /* 1) команди — без блокування */
        RegCmd_t cmd;
        int32_t  sp_before = sp_mv;
        while (xQueueReceive(queue, &cmd, 0) == pdTRUE) {
            sp_mv = clamp_sp(cmd.type == RCMD_SP_DELTA ? sp_mv + cmd.value_mv : cmd.value_mv);
        }

        /* 2) нові коефіцієнти з вебсторінки / дебагера */
        PidTuning_t want;
        portENTER_CRITICAL(&mux);
        want.kp = g_pid_tuning.kp; want.ki = g_pid_tuning.ki; want.kd = g_pid_tuning.kd;
        portEXIT_CRITICAL(&mux);
        if (want.kp != applied.kp || want.ki != applied.ki || want.kd != applied.kd) {
            applied = want;
            PID_SetGains(&pid, applied.kp, applied.ki, applied.kd);
        }

        /* 3) замкнутий контур: вимір → PID → ШІМ */
        int32_t y_mv = (int32_t)AdcIn_ReadMv(adc);
        if (sp_mv != sp_before) {                    /* новий крок — починаємо міряти */
            metrics_new_step(&sm, y_mv, sp_mv, now);
            settle_ms = -1;
        }
        float u = PID_Update(&pid, sp_mv / 1000.0f, y_mv / 1000.0f);
        Pwm_SetDuty(pwm, u);

        /* 4) "вийшов на уставку" + показники якості */
        int32_t err = sp_mv - y_mv;
        if (abs(err) <= CFG_SETTLED_BAND_MV) {
            if (!in_band) { in_band = true; in_band_since = now; }
        } else {
            in_band = false;
        }
        bool now_settled = in_band && (uint32_t)(now - in_band_since) >= CFG_SETTLED_TIME_MS;

        if (sm.active) {
            bool up = sm.target_mv >= sm.start_mv;
            if (up ? (y_mv > sm.peak_mv) : (y_mv < sm.peak_mv)) sm.peak_mv = y_mv;
            int32_t span = abs(sm.target_mv - sm.start_mv);
            int32_t over = up ? (sm.peak_mv - sm.target_mv) : (sm.target_mv - sm.peak_mv);
            overshoot = (span > 0 && over > 0) ? 100.0f * (float)over / (float)span : 0.0f;
            if (now_settled) {                       /* час входу в смугу, без 300 мс підтвердження */
                settle_ms = (int32_t)(in_band_since - sm.t_step_ms);
                sm.active = false;
            }
        }
        if (now_settled != settled) {
            settled = now_settled;
            EventBus_Publish(TOPIC_REG_SETTLED, settled ? 1 : 0);
        }

        uint32_t us = (uint32_t)(esp_timer_get_time() - t0);
        if (us > exec_max) exec_max = us;

        /* 5) телеметрія — одним атомарним блоком */
        portENTER_CRITICAL(&mux);
        g_reg.t_ms          = now;
        g_reg.setpoint_mv   = sp_mv;
        g_reg.measured_mv   = y_mv;
        g_reg.error_mv      = err;
        g_reg.adc_raw       = adc->last_raw;
        g_reg.pwm_raw       = pwm->last_duty;
        g_reg.duty_pct      = u * 100.0f;
        g_reg.p = pid.p_term; g_reg.i = pid.i_term; g_reg.d = pid.d_term;
        g_reg.settled       = settled;
        g_reg.overshoot_pct = overshoot;
        g_reg.settle_ms     = settle_ms;
        g_reg.exec_us       = us;
        g_reg.exec_us_max   = exec_max;
        g_reg.overruns      = overruns;
        portEXIT_CRITICAL(&mux);
    }
}

void Regulator_Init(Pwm_t *pwm_out, AdcIn_t *adc_in)
{
    pwm = pwm_out;
    adc = adc_in;

    queue = xQueueCreateStatic(REG_QUEUE_LEN, sizeof(RegCmd_t), qbuf, &qcb);
    bool ok = EventBus_Subscribe(TOPIC_ENCODER_STEP, on_encoder, NULL) &&
              EventBus_Subscribe(TOPIC_BUTTON,       on_button,  NULL);

    TaskHandle_t h = xTaskCreateStaticPinnedToCore(RegulatorTask, "pid", REG_STACK_BYTES, NULL,
                                                   CFG_PRIO_REGULATOR, stack, &tcb, CFG_RT_CORE);
    configASSERT(queue != NULL && ok && h != NULL);
    (void)ok; (void)h;
}

void Regulator_GetStatus(RegStatus_t *out)
{
    portENTER_CRITICAL(&mux);
    memcpy(out, (const void *)&g_reg, sizeof *out);
    portEXIT_CRITICAL(&mux);
}

void Regulator_GetTuning(PidTuning_t *out)
{
    portENTER_CRITICAL(&mux);
    out->kp = g_pid_tuning.kp; out->ki = g_pid_tuning.ki; out->kd = g_pid_tuning.kd;
    portEXIT_CRITICAL(&mux);
}

void Regulator_SetTuning(float kp, float ki, float kd)
{
    portENTER_CRITICAL(&mux);          /* три числа змінюються разом, не по одному */
    g_pid_tuning.kp = kp; g_pid_tuning.ki = ki; g_pid_tuning.kd = kd;
    portEXIT_CRITICAL(&mux);
}

void Regulator_ResetStats(void) { reset_stats_req = true; }
