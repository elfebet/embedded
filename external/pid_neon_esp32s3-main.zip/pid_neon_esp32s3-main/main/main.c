/**
 * main.c — app_main(): точка входу ESP-IDF.
 *
 * На STM32 main() сам налаштовував такти, периферію і запускав планувальник.
 * В ESP-IDF планувальник FreeRTOS УЖЕ працює до виклику app_main() — це
 * звичайна задача "main". Порядок:
 *   1) NVS          — флеш-сховище, потрібне драйверу Wi-Fi (калібрування радіо);
 *   2) esp_netif    — TCP/IP-стек (lwIP);
 *   3) Event Loop   — системний цикл подій (WIFI_EVENT, IP_EVENT, MQTT…);
 *   4) LogTap       — копія журналу для сторінки;
 *   5) App_Init     — PID, мотор, світлодіоди. Працюють уже з цієї миті!
 *   6) Wi-Fi        — чекаємо IP (STA) або піднімаємо AP;
 *   7) вебсервер і (необов'язково) MQTT.
 */
#include "app.h"
#include "app_config.h"
#include "app_remote.h"
#include "net_wifi.h"
#include "net_web.h"
#include "net_mqtt.h"
#include "net_logtap.h"

#include "nvs_flash.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "esp_log.h"
#include "sdkconfig.h"

static const char *TAG = "main";

/* Сторінка вшита у прошивку (main/CMakeLists.txt → EMBED_FILES).
   Лінкер створює символи початку і кінця бінарного ресурсу. */
extern const uint8_t index_html_start[] asm("_binary_index_html_start");
extern const uint8_t index_html_end[]   asm("_binary_index_html_end");

void app_main(void)
{
    /* 1) NVS: якщо розмітка змінилась — стерти і ініціалізувати заново */
    esp_err_t r = nvs_flash_init();
    if (r == ESP_ERR_NVS_NO_FREE_PAGES || r == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        r = nvs_flash_init();
    }
    ESP_ERROR_CHECK(r);

    /* 2–3) мережевий стек і системний цикл подій */
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    /* 4) журнал → сторінка */
    LogTap_Init();
    ESP_LOGI(TAG, "NEON//PID на ESP32-S3: старт");

    /* 5) керування — ДО мережі */
    App_Init();
    Remote_StartTelemetryLog();

    /* 6) Wi-Fi (блокує лише задачу main, решта задач уже працює) */
    const NetWifiConfig_t wcfg = {
        .sta_ssid      = CONFIG_APP_WIFI_SSID,
        .sta_pass      = CONFIG_APP_WIFI_PASSWORD,
        .sta_max_retry = CONFIG_APP_WIFI_MAX_RETRY,
        .ap_ssid       = CONFIG_APP_AP_SSID,
        .ap_pass       = CONFIG_APP_AP_PASSWORD,
    };
    NetWifi_Start(&wcfg);

    /* 7) вебсервер + MQTT */
    NetWeb_Start(Remote_Api(), index_html_start,
                 (size_t)(index_html_end - index_html_start), CFG_WS_PUSH_MS);

#if CONFIG_APP_MQTT_ENABLE
    if (NetWifi_Mode() == NET_MODE_STA) {           /* у режимі AP інтернету немає */
        NetMqtt_Start(CONFIG_APP_MQTT_BROKER_URI, CONFIG_APP_MQTT_TOPIC_PREFIX,
                      Remote_Api(), CONFIG_APP_MQTT_PERIOD_MS);
    }
#endif

    ESP_LOGI(TAG, "готово: http://%s", NetWifi_Ip());
    /* app_main може просто завершитись — задачі живуть далі */
}
