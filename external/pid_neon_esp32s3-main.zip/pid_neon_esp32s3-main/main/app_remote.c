/**
 * app_remote.c — JSON-телеметрія, розбір команд (cJSON), журнал g_reg.
 *
 * command() викликається з задачі мережі (httpd або mqtt). Вона лише
 * публікує подію на шину — а колбеки підписників тільки кладуть її в черги.
 * Тому мережа ніколи не блокує регулятор і не тримає жодних м'ютексів.
 */
#include "app_remote.h"
#include "app_config.h"
#include "app_regulator.h"
#include "app_motor_ctrl.h"
#include "svc_event_bus.h"
#include "net_wifi.h"
#include "net_web.h"
#include "net_logtap.h"

#include <stdio.h>
#include <string.h>
#include "cJSON.h"
#include "esp_log.h"
#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "remote";
static const char *TAG_TEL = "g_reg";

#define REMOTE_MAX_STEPS  30        /* захист від "стрибка" на весь діапазон */

/* ------------------------------ телеметрія ------------------------------ */
static size_t status_json(char *buf, size_t max)
{
    RegStatus_t r;
    PidTuning_t k;
    Regulator_GetStatus(&r);
    Regulator_GetTuning(&k);
    MotorState_t m = MotorCtrl_GetState();

    int n = snprintf(buf, max,
        "{\"t\":\"tel\",\"ms\":%lu,"
        "\"sp\":%ld,\"y\":%ld,\"e\":%ld,\"raw\":%ld,\"pwm\":%lu,\"duty\":%.2f,"
        "\"p\":%.4f,\"i\":%.4f,\"d\":%.4f,\"st\":%d,\"os\":%.1f,\"ts\":%ld,"
        "\"ex\":%lu,\"exm\":%lu,\"ovr\":%lu,"
        "\"kp\":%.3f,\"ki\":%.3f,\"kd\":%.3f,"
        "\"m\":%d,\"mn\":\"%s\",\"r1\":%d,\"r2\":%d,\"drop\":%lu,"
        "\"spmin\":%d,\"spmax\":%d,\"spstep\":%d,"
        "\"heap\":%lu,\"ip\":\"%s\",\"wifi\":\"%s\",\"rssi\":%d,\"ws\":%d}",
        (unsigned long)r.t_ms,
        (long)r.setpoint_mv, (long)r.measured_mv, (long)r.error_mv, (long)r.adc_raw,
        (unsigned long)r.pwm_raw, r.duty_pct,
        r.p, r.i, r.d, r.settled ? 1 : 0, r.overshoot_pct, (long)r.settle_ms,
        (unsigned long)r.exec_us, (unsigned long)r.exec_us_max, (unsigned long)r.overruns,
        k.kp, k.ki, k.kd,
        (int)m, MotorFsm_StateName(m), m == MS_RUN_CW, m == MS_RUN_CCW,
        (unsigned long)MotorCtrl_DroppedEvents(),
        CFG_SP_MIN_MV, CFG_SP_MAX_MV, CFG_SP_STEP_MV,
        (unsigned long)esp_get_free_heap_size(), NetWifi_Ip(),
        NetWifi_Mode() == NET_MODE_STA ? "STA" : NetWifi_Mode() == NET_MODE_AP ? "AP" : "-",
        NetWifi_Rssi(), NetWeb_WsClients());
    if (n < 0) return 0;
    return ((size_t)n < max) ? (size_t)n : max - 1;
}

/* ------------------------------- команди ------------------------------- */
static bool gain_ok(const cJSON *v, float lo, float hi, float *out)
{
    if (!cJSON_IsNumber(v)) return false;
    float x = (float)v->valuedouble;
    if (x < lo || x > hi) return false;
    *out = x;
    return true;
}

static void command(const char *json, size_t len)
{
    cJSON *root = cJSON_ParseWithLength(json, len);
    if (root == NULL) { ESP_LOGW(TAG, "невалідний JSON"); return; }

    const cJSON *cmd = cJSON_GetObjectItemCaseSensitive(root, "cmd");
    if (!cJSON_IsString(cmd)) {
        ESP_LOGW(TAG, "немає поля \"cmd\"");
    }
    else if (strcmp(cmd->valuestring, "enc") == 0) {          /* повзунок = віртуальний енкодер */
        const cJSON *s = cJSON_GetObjectItemCaseSensitive(root, "steps");
        if (cJSON_IsNumber(s)) {
            int steps = s->valueint;
            if (steps >  REMOTE_MAX_STEPS) steps =  REMOTE_MAX_STEPS;
            if (steps < -REMOTE_MAX_STEPS) steps = -REMOTE_MAX_STEPS;
            if (steps != 0) {
                ESP_LOGI(TAG, "повзунок: %+d клацань (%+d мВ) → %s", steps, steps * CFG_SP_STEP_MV,
                         steps > 0 ? "CW, червоний" : "CCW, синій");
                EventBus_Publish(TOPIC_ENCODER_STEP, steps);
            }
        }
    }
    else if (strcmp(cmd->valuestring, "stop") == 0) {         /* = кнопка */
        ESP_LOGW(TAG, "STOP зі сторінки: мотор стоп, уставка %d мВ", CFG_SP_MIN_MV);
        EventBus_Publish(TOPIC_BUTTON, 1);
    }
    else if (strcmp(cmd->valuestring, "pid") == 0) {
        float kp, ki, kd;
        if (gain_ok(cJSON_GetObjectItemCaseSensitive(root, "kp"), 0.0f, 50.0f, &kp) &&
            gain_ok(cJSON_GetObjectItemCaseSensitive(root, "ki"), 0.0f, 100.0f, &ki) &&
            gain_ok(cJSON_GetObjectItemCaseSensitive(root, "kd"), 0.0f, 10.0f, &kd)) {
            Regulator_SetTuning(kp, ki, kd);
            ESP_LOGI(TAG, "нові коефіцієнти: Kp=%.3f Ki=%.3f Kd=%.3f", kp, ki, kd);
        } else {
            ESP_LOGW(TAG, "pid: потрібні kp 0…50, ki 0…100, kd 0…10");
        }
    }
    else if (strcmp(cmd->valuestring, "reset") == 0) {
        Regulator_ResetStats();
        ESP_LOGI(TAG, "лічильники exec_us_max і overruns скинуто");
    }
    else {
        ESP_LOGW(TAG, "невідома команда \"%s\"", cmd->valuestring);
    }
    cJSON_Delete(root);
}

static const NetApi_t API = {
    .status_json = status_json,
    .command     = command,
    .next_log    = LogTap_Read,
};

const NetApi_t *Remote_Api(void) { return &API; }

/* ------------------- журнал g_reg: "логи PID" у UART і на сторінку ------------------- */
static StaticTask_t tlog_tcb;
static StackType_t  tlog_stack[4096];

static void tlog_task(void *arg)
{
    (void)arg;
    TickType_t last = xTaskGetTickCount();
    for (;;) {
        xTaskDelayUntil(&last, pdMS_TO_TICKS(CFG_LOG_PERIOD_MS));
        RegStatus_t r;
        Regulator_GetStatus(&r);
        ESP_LOGI(TAG_TEL, "SP=%4ld Y=%4ld E=%+4ld ADC=%4ld duty=%5.1f%% P=%+.3f I=%.3f D=%+.3f %s ex=%luus",
                 (long)r.setpoint_mv, (long)r.measured_mv, (long)r.error_mv, (long)r.adc_raw,
                 r.duty_pct, r.p, r.i, r.d, r.settled ? "SETTLED" : "moving ",
                 (unsigned long)r.exec_us);
    }
}

void Remote_StartTelemetryLog(void)
{
    xTaskCreateStatic(tlog_task, "tlog", sizeof tlog_stack, NULL, CFG_PRIO_TLOG, tlog_stack, &tlog_tcb);
}
