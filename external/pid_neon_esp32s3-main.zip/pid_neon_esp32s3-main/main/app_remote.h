/**
 * app_remote.h — адаптер "застосунок ↔ мережа" (патерн Adapter / Facade).
 *
 * Реалізує контракт NetApi_t (net_api.h):
 *   Remote_StatusJson — знімок g_reg + стан мотора → JSON;
 *   Remote_Command    — JSON-команда від сторінки/REST/MQTT → події на шині;
 *   Remote_NextLog    — рядок журналу для вікна логів.
 * Плюс задача "tlog": 2 рази/с друкує g_reg у журнал (UART і сторінка).
 *
 * ВІРТУАЛЬНИЙ ЕНКОДЕР: повзунок на сторінці надсилає {"cmd":"enc","steps":N}.
 * Ми публікуємо TOPIC_ENCODER_STEP — рівно ту саму подію, що й KY-040.
 * Регулятор і мотор не знають, звідки прийшов крок.
 */
#ifndef APP_REMOTE_H
#define APP_REMOTE_H

#include "net_api.h"

const NetApi_t *Remote_Api(void);
void            Remote_StartTelemetryLog(void);

#endif /* APP_REMOTE_H */
