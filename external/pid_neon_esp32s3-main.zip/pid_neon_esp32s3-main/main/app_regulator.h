/**
 * app_regulator.h — задача PID-регулятора (Active Object) і її телеметрія.
 *
 * На ESP32-S3 задача закріплена за ядром 1, а знімок стану для вебсторінки
 * (інша задача, можливо інше ядро) читається під спін-блокуванням
 * portMUX — щоб усі поля були з ОДНОГО такту регулятора.
 */
#ifndef APP_REGULATOR_H
#define APP_REGULATOR_H

#include "drv_pwm.h"
#include "drv_adc.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint32_t t_ms;                  /* час такту від старту                     */
    int32_t  setpoint_mv;           /* уставка                                  */
    int32_t  measured_mv;           /* вимір (АЦП, калібрований)                */
    int32_t  error_mv;
    int32_t  adc_raw;               /* сирий код АЦП 0…4095                     */
    uint32_t pwm_raw;               /* код ШІМ 0…1023                           */
    float    duty_pct;              /* шпаруватість ШІМ, %                      */
    float    p, i, d;               /* складові PID                              */
    bool     settled;               /* вийшов на уставку                         */
    float    overshoot_pct;         /* перерегулювання останнього кроку          */
    int32_t  settle_ms;             /* час встановлення останнього кроку; −1 = ще ні */
    uint32_t exec_us, exec_us_max;  /* час виконання такту                       */
    uint32_t overruns;              /* пропущені такти                           */
} RegStatus_t;

typedef struct { float kp, ki, kd; } PidTuning_t;

extern volatile RegStatus_t g_reg;         /* для JTAG-дебагера (як на STM32)   */
extern volatile PidTuning_t g_pid_tuning;

void Regulator_Init(Pwm_t *pwm, AdcIn_t *adc);
void Regulator_GetStatus(RegStatus_t *out);          /* узгоджений знімок         */
void Regulator_GetTuning(PidTuning_t *out);
void Regulator_SetTuning(float kp, float ki, float kd);
void Regulator_ResetStats(void);

#endif /* APP_REGULATOR_H */
