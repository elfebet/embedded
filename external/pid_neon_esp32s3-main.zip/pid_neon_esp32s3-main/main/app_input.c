/**
 * app_input.c — періодичне опитування (10 мс), порт з STM32.
 */
#include "app_input.h"
#include "app_config.h"
#include "svc_event_bus.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define INPUT_PERIOD_MS       10u
#define INPUT_STACK_BYTES     3072u
#define MAX_STEPS_PER_PERIOD  4

static StaticTask_t tcb;
static StackType_t  stack[INPUT_STACK_BYTES];
static Encoder_t   *enc;
static Button_t    *btn;

static void InputTask(void *arg)
{
    (void)arg;
    TickType_t last = xTaskGetTickCount();
    for (;;) {
        xTaskDelayUntil(&last, pdMS_TO_TICKS(INPUT_PERIOD_MS));

        if (Button_PollPressed(btn)) EventBus_Publish(TOPIC_BUTTON, 1);

        if (enc) {
            int32_t det = Encoder_ReadDetents(enc);
            if (det >  MAX_STEPS_PER_PERIOD) det =  MAX_STEPS_PER_PERIOD;
            if (det < -MAX_STEPS_PER_PERIOD) det = -MAX_STEPS_PER_PERIOD;
            if (det != 0) EventBus_Publish(TOPIC_ENCODER_STEP, det);
        }
    }
}

void Input_Init(Encoder_t *encoder, Button_t *button)
{
    enc = encoder;
    btn = button;
    TaskHandle_t h = xTaskCreateStaticPinnedToCore(InputTask, "input", INPUT_STACK_BYTES, NULL,
                                                   CFG_PRIO_INPUT, stack, &tcb, CFG_RT_CORE);
    configASSERT(h != NULL);
    (void)h;
}
