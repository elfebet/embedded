/**
 * app_indicator.c — порт з STM32 без змін логіки. Heartbeat — програмний
 * таймер FreeRTOS (окрема задача не потрібна).
 */
#include "app_indicator.h"
#include "app_motor_fsm.h"
#include "app_config.h"
#include "svc_event_bus.h"

#include "freertos/FreeRTOS.h"
#include "freertos/timers.h"

#define BLINK_FAST_MS  100u

static Led_t *led_red, *led_blue, *led_heart;
static StaticTimer_t heart_tcb;
static TimerHandle_t heart_timer;

static void on_motor_state(void *ctx, BusTopic_t topic, int32_t value)
{
    (void)ctx; (void)topic;
    MotorState_t s = (MotorState_t)value;
    Led_Set(led_red,  s == MS_RUN_CW);
    Led_Set(led_blue, s == MS_RUN_CCW);
}

static void on_reg_settled(void *ctx, BusTopic_t topic, int32_t settled)
{
    (void)ctx; (void)topic;
    if (heart_timer)
        xTimerChangePeriod(heart_timer, pdMS_TO_TICKS(settled ? CFG_HEARTBEAT_MS : BLINK_FAST_MS), 0);
}

static void on_heartbeat(TimerHandle_t t)
{
    (void)t;
    Led_Toggle(led_heart);
}

void Indicator_Init(Led_t *red, Led_t *blue, Led_t *heartbeat)
{
    led_red   = red;
    led_blue  = blue;
    led_heart = heartbeat;
    Led_Set(led_red,  false);
    Led_Set(led_blue, false);

    if (led_heart) {
        heart_timer = xTimerCreateStatic("heart", pdMS_TO_TICKS(BLINK_FAST_MS), pdTRUE,
                                         NULL, on_heartbeat, &heart_tcb);
        xTimerStart(heart_timer, 0);
    }
    bool ok = EventBus_Subscribe(TOPIC_MOTOR_STATE, on_motor_state, NULL) &&
              EventBus_Subscribe(TOPIC_REG_SETTLED, on_reg_settled, NULL);
    configASSERT(ok);
    (void)ok;
}
